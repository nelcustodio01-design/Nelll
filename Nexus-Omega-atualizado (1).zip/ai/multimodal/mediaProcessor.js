// ═══════════════════════════════════════════════════════════════
//  MEDIA PROCESSOR — Processamento Multimodal de Elite
//  Nel-Aviso-Bot-Moz 🇲🇿 — Cérebro de IA Elite
//
//  Capacidades:
//  • Transcrição de áudio/voz → texto (Whisper)
//  • Análise de imagens (comprovativo, produto, etc.)
//  • Extracção de texto de documentos
//  • Análise de vídeos curtos
// ═══════════════════════════════════════════════════════════════
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import fetch from 'node-fetch';
import FormData from 'form-data';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const TMP_DIR   = path.join(__dirname, '..', '..', 'tmp');

// Garantir directório temporário
if (!fs.existsSync(TMP_DIR)) fs.mkdirSync(TMP_DIR, { recursive: true });

// ── Configuração da API ──────────────────────────────────────
const OPENAI_BASE = process.env.OPENAI_API_BASE || 'https://api.openai.com/v1';
const OPENAI_KEY  = process.env.OPENAI_API_KEY  || '';

const MediaProcessor = {

  /**
   * Transcrever áudio/voz para texto usando Whisper
   * @param {Buffer} audioBuffer - Buffer do ficheiro de áudio
   * @param {string} mimetype    - Tipo MIME (audio/ogg, audio/mp4, etc.)
   * @returns {string} Texto transcrito
   */
  async transcribeAudio(audioBuffer, mimetype = 'audio/ogg') {
    const ext      = _mimeToExt(mimetype);
    const tmpFile  = path.join(TMP_DIR, `audio_${Date.now()}${ext}`);

    try {
      fs.writeFileSync(tmpFile, audioBuffer);

      const form = new FormData();
      form.append('file', fs.createReadStream(tmpFile), {
        filename: `audio${ext}`,
        contentType: mimetype,
      });
      form.append('model', 'whisper-1');
      form.append('language', 'pt');
      form.append('response_format', 'text');

      const res = await fetch(`${OPENAI_BASE}/audio/transcriptions`, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${OPENAI_KEY}`,
          ...form.getHeaders(),
        },
        body: form,
      });

      if (!res.ok) {
        const err = await res.text();
        throw new Error(`Whisper API error: ${err}`);
      }

      const text = await res.text();
      return text.trim();

    } finally {
      try { fs.unlinkSync(tmpFile); } catch {}
    }
  },

  /**
   * Analisar imagem com GPT-4o Vision
   * @param {Buffer} imageBuffer - Buffer da imagem
   * @param {string} mimetype    - Tipo MIME (image/jpeg, image/png, etc.)
   * @param {string} prompt      - Instrução de análise
   * @returns {string} Descrição/análise da imagem
   */
  async analyzeImage(imageBuffer, mimetype = 'image/jpeg', prompt = null) {
    const base64  = imageBuffer.toString('base64');
    const dataUrl = `data:${mimetype};base64,${base64}`;

    const systemPrompt = prompt || `Analisa esta imagem detalhadamente. 
    Se for um comprovativo de pagamento, extrai: valor, data, referência, banco.
    Se for um produto, descreve características e possível preço.
    Se for um documento, resume o conteúdo principal.
    Responde sempre em Português de Moçambique.`;

    const res = await fetch(`${OPENAI_BASE}/chat/completions`, {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${OPENAI_KEY}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        model: 'gpt-4o',
        messages: [
          {
            role: 'user',
            content: [
              { type: 'text',      text: systemPrompt },
              { type: 'image_url', image_url: { url: dataUrl, detail: 'high' } },
            ],
          },
        ],
        max_tokens: 500,
      }),
    });

    if (!res.ok) {
      const err = await res.text();
      throw new Error(`Vision API error: ${err}`);
    }

    const data = await res.json();
    return data.choices?.[0]?.message?.content || 'Não foi possível analisar a imagem.';
  },

  /**
   * Processar mensagem multimodal — detecta tipo e processa
   * @param {object} m - Objecto de mensagem serializado
   * @returns {{ type: string, text: string, originalMedia: boolean }}
   */
  async processMessage(m) {
    // Mensagem de texto simples
    if (!m.isMedia && m.text) {
      return { type: 'text', text: m.text, originalMedia: false };
    }

    // Áudio / Voz
    if (m.isAudio || m.mtype === 'audioMessage' || m.mtype === 'pttMessage') {
      try {
        const buffer     = await m.download();
        const transcript = await MediaProcessor.transcribeAudio(buffer, m.mimetype || 'audio/ogg');
        return {
          type: 'audio',
          text: `[O utilizador enviou um áudio. Transcrição: "${transcript}"]`,
          transcript,
          originalMedia: true,
        };
      } catch (e) {
        console.error('[MediaProcessor] Erro ao transcrever áudio:', e.message);
        return {
          type: 'audio',
          text: '[O utilizador enviou um áudio mas não foi possível transcrever.]',
          originalMedia: true,
        };
      }
    }

    // Imagem
    if (m.isImage || m.mtype === 'imageMessage') {
      try {
        const buffer  = await m.download();
        const caption = m.text || '';
        const prompt  = caption
          ? `O utilizador enviou esta imagem com a legenda: "${caption}". Analisa a imagem e responde ao contexto da legenda.`
          : null;
        const analysis = await MediaProcessor.analyzeImage(buffer, m.mimetype || 'image/jpeg', prompt);
        return {
          type: 'image',
          text: `[O utilizador enviou uma imagem. Análise: "${analysis}"]`,
          analysis,
          caption,
          originalMedia: true,
        };
      } catch (e) {
        console.error('[MediaProcessor] Erro ao analisar imagem:', e.message);
        const caption = m.text || '';
        return {
          type: 'image',
          text: caption
            ? `[O utilizador enviou uma imagem com a legenda: "${caption}"]`
            : '[O utilizador enviou uma imagem.]',
          originalMedia: true,
        };
      }
    }

    // Documento
    if (m.isDocument || m.mtype === 'documentMessage') {
      const filename = m.msg?.fileName || 'documento';
      const caption  = m.text || '';
      return {
        type: 'document',
        text: caption
          ? `[O utilizador enviou o documento "${filename}" com a nota: "${caption}"]`
          : `[O utilizador enviou o documento "${filename}"]`,
        filename,
        originalMedia: true,
      };
    }

    // Vídeo
    if (m.isVideo || m.mtype === 'videoMessage') {
      const caption = m.text || '';
      return {
        type: 'video',
        text: caption
          ? `[O utilizador enviou um vídeo com a legenda: "${caption}"]`
          : '[O utilizador enviou um vídeo.]',
        originalMedia: true,
      };
    }

    // Sticker
    if (m.isSticker) {
      return {
        type: 'sticker',
        text: '[O utilizador enviou um sticker/emoji animado.]',
        originalMedia: true,
      };
    }

    // Fallback
    return {
      type: 'unknown',
      text: m.text || '[Mensagem não reconhecida]',
      originalMedia: false,
    };
  },
};

// ── Utilitários ──────────────────────────────────────────────
function _mimeToExt(mime) {
  const map = {
    'audio/ogg':  '.ogg',
    'audio/mp4':  '.mp4',
    'audio/mpeg': '.mp3',
    'audio/wav':  '.wav',
    'audio/webm': '.webm',
    'audio/aac':  '.aac',
    'audio/opus': '.opus',
  };
  return map[mime] || '.ogg';
}

export default MediaProcessor;
