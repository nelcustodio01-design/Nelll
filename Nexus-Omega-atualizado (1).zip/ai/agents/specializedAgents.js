/**
 * Specialized Agents (Nível Deus - Fase 2.2)
 * Nel-Aviso-Bot-Moz 🇲🇿
 *
 * Agentes especializados com prompts e ferramentas optimizados:
 * - SalesAgent: Vendas consultivas
 * - SupportAgent: Suporte técnico
 * - MarketingAgent: Marketing digital
 * - ResearchAgent: Pesquisa e análise
 * - AnalyticsAgent: Dados e métricas
 */

import fetch from 'node-fetch';
import MultiAgentOrchestrator, { AGENT_DEFINITIONS } from './orchestrator.js';

const OPENAI_BASE = process.env.OPENAI_API_BASE || 'https://api.openai.com/v1';
const OPENAI_KEY  = process.env.OPENAI_API_KEY  || '';
const MODEL_MAIN  = process.env.AI_MODEL        || 'gpt-4o';
const MODEL_FAST  = process.env.AI_MODEL_FAST   || 'gpt-4o-mini';

// ── Especializações de Agentes ────────────────────────────────

const SPECIALIZED_PROMPTS = {
  sales: {
    addendum: `
## TÉCNICAS DE VENDA
- **SPIN Selling**: Situação → Problema → Implicação → Necessidade
- **BANT**: Orçamento → Autoridade → Necessidade → Prazo
- **Sandler**: Qualificar cedo, desqualificar cedo
- Sempre feche com uma pergunta de compromisso

## OBJECTIVOS
- Converter leads em clientes pagantes
- Upselling: sugerir pacotes superiores
- Cross-selling: sugerir produtos complementares
- Nurturing: manter contacto com leads frios
`,
  },
  support: {
    addendum: `
## METODOLOGIA DE SUPORTE
1. **Ouça**: Entenda o problema completamente
2. **Empatize**: "Compreendo a sua frustração..."
3. **Diagnostique**: Faça perguntas de clarificação
4. **Resolva**: Dê instruções passo a passo
5. **Confirme**: "O problema foi resolvido?"
6. **Documente**: Registe a solução

## NÍVEIS DE ESCALONAMENTO
- Nível 1: FAQ e guias básicos (automático)
- Nível 2: Problemas complexos (agente IA)
- Nível 3: Bugs e erros técnicos (humano)
`,
  },
  marketing: {
    addendum: `
## ESTRATÉGIAS DE MARKETING
- **AIDA**: Atenção → Interesse → Desejo → Acção
- **Content Marketing**: Educar antes de vender
- **Social Proof**: Depoimentos e resultados
- **Urgência**: Ofertas limitadas no tempo
- **Personalização**: Conteúdo adaptado ao perfil

## CANAIS PRIORITÁRIOS (Moçambique)
1. WhatsApp (máximo alcance)
2. Instagram (visual e engajamento)
3. Facebook (comunidade e anúncios)
4. TikTok (crescimento jovem)
`,
  },
  research: {
    addendum: `
## METODOLOGIA DE PESQUISA
- Fontes primárias: dados do bot, feedback de clientes
- Fontes secundárias: notícias, relatórios, APIs
- Validação cruzada: confirmar dados em múltiplas fontes
- Datação: sempre incluir data da informação

## FORMATO DE RELATÓRIOS
1. Resumo executivo (2-3 frases)
2. Dados principais (com fontes)
3. Análise e interpretação
4. Recomendações acionáveis
`,
  },
  analytics: {
    addendum: `
## KPIs PRINCIPAIS
- Taxa de conversão (leads → clientes)
- Tempo médio de resposta
- Satisfação do cliente (CSAT)
- Receita por utilizador
- Retenção e churn rate
- ROI de campanhas

## ANÁLISE DE DADOS
- Use percentagens e comparações
- Identifique tendências ao longo do tempo
- Compare com benchmarks do sector
- Sugira acções baseadas em dados
`,
  },
};

// ── Agente Base ───────────────────────────────────────────────

class SpecializedAgent {
  constructor(agentId, orchestrator, context = {}) {
    this.agentId = agentId;
    this.orchestrator = orchestrator;
    this.context = context;
    this.definition = AGENT_DEFINITIONS[agentId];
    this.specialization = SPECIALIZED_PROMPTS[agentId] || {};
    this.conversationHistory = [];
    this.maxHistory = 20;
  }

  /**
   * Processar mensagem com este agente especializado
   */
  async process(text, userProfile = {}) {
    const systemPrompt = this._buildSystemPrompt(userProfile);
    const tools = this._getToolDefinitions();

    // Construir mensagens
    const messages = [
      { role: 'system', content: systemPrompt },
      ...this.conversationHistory,
      { role: 'user', content: text },
    ];

    // Chamar LLM com ferramentas
    const response = await this._callLLM(messages, tools);

    // Guardar no histórico
    this.conversationHistory.push({ role: 'user', content: text });

    if (response.finish_reason === 'tool_calls') {
      return await this._processToolCalls(response, messages);
    }

    const finalContent = response.message?.content;
    if (finalContent) {
      this.conversationHistory.push({ role: 'assistant', content: finalContent });
      this._pruneHistory();
    }

    return finalContent;
  }

  _buildSystemPrompt(userProfile = {}) {
    let prompt = this.definition.systemPrompt;

    // Adicionar especialização
    if (this.specialization.addendum) {
      prompt += this.specialization.addendum;
    }

    // Adicionar contexto do perfil
    if (userProfile.name) prompt += `\nCliente: ${userProfile.name}`;
    if (userProfile.purchase_stage) prompt += `\nEtapa no funil: ${userProfile.purchase_stage}`;
    if (userProfile.interests?.length) prompt += `\nInteresses: ${userProfile.interests.join(', ')}`;

    prompt += `\n\nData/hora: ${new Date().toLocaleString('pt-MZ', { timeZone: 'Africa/Maputo' })}`;

    return prompt;
  }

  _getToolDefinitions() {
    // Ferramentas básicas + ferramentas do agente específico
    const basicTools = [
      {
        type: 'function',
        function: {
          name: 'transfer_to_agent',
          description: 'Transferir a conversa para outro agente especializado.',
          parameters: {
            type: 'object',
            properties: {
              target_agent: {
                type: 'string',
                enum: ['sales', 'support', 'marketing', 'research', 'analytics'],
                description: 'Agente para o qual transferir',
              },
              reason: { type: 'string', description: 'Motivo da transferência' },
            },
            required: ['target_agent', 'reason'],
          },
        },
      },
    ];
    return basicTools;
  }

  async _processToolCalls(response, messages) {
    const toolCalls = response.message.tool_calls || [];

    for (const toolCall of toolCalls) {
      if (toolCall.function.name === 'transfer_to_agent') {
        const args = JSON.parse(toolCall.function.arguments || '{}');
        return {
          type: 'handoff',
          targetAgent: args.target_agent,
          reason: args.reason,
          message: `🔄 A transferir para o agente ${AGENT_DEFINITIONS[args.target_agent]?.name || args.target_agent}... Motivo: ${args.reason}`,
        };
      }
    }

    return response.message?.content;
  }

  async _callLLM(messages, tools = []) {
    if (!OPENAI_KEY) {
      return { message: { content: 'IA não disponível. Por favor, configure a chave API.' }, finish_reason: 'stop' };
    }

    const payload = {
      model: MODEL_FAST,
      messages,
      temperature: 0.7,
      max_tokens: 600,
    };

    if (tools.length > 0) {
      payload.tools = tools;
      payload.tool_choice = 'auto';
    }

    const res = await fetch(`${OPENAI_BASE}/chat/completions`, {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${OPENAI_KEY}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(payload),
    });

    if (!res.ok) {
      const err = await res.text();
      throw new Error(`Agent LLM error (${res.status}): ${err}`);
    }

    const data = await res.json();
    return {
      message: data.choices?.[0]?.message,
      finish_reason: data.choices?.[0]?.finish_reason,
      usage: data.usage,
    };
  }

  _pruneHistory() {
    if (this.conversationHistory.length > this.maxHistory * 2) {
      this.conversationHistory = this.conversationHistory.slice(-this.maxHistory);
    }
  }

  reset() {
    this.conversationHistory = [];
  }
}

// ── Factory ───────────────────────────────────────────────────

class AgentFactory {
  constructor(context = {}) {
    this.context = context;
    this.orchestrator = new MultiAgentOrchestrator(context);
    this.agents = new Map();
  }

  createAgent(agentId) {
    if (this.agents.has(agentId)) return this.agents.get(agentId);
    const agent = new SpecializedAgent(agentId, this.orchestrator, this.context);
    this.agents.set(agentId, agent);
    return agent;
  }

  getOrchestrator() {
    return this.orchestrator;
  }

  async processWithBestAgent(text, userProfile = {}) {
    const route = await this.orchestrator.processMessage(text, userProfile);
    const agent = this.createAgent(route.agentId);
    const response = await agent.process(text, userProfile);

    // Verificar se precisa de handoff
    if (response?.type === 'handoff') {
      const targetAgent = this.createAgent(response.targetAgent);
      return await targetAgent.process(text, userProfile);
    }

    return {
      agentId: route.agentId,
      agentName: route.agentName,
      response: typeof response === 'string' ? response : response?.message || 'Sem resposta.',
    };
  }

  getAllAgents() {
    return Object.keys(AGENT_DEFINITIONS).map(id => ({
      id,
      name: AGENT_DEFINITIONS[id].name,
      description: AGENT_DEFINITIONS[id].description,
    }));
  }
}

export default AgentFactory;
export { SpecializedAgent, AgentFactory, SPECIALIZED_PROMPTS };
