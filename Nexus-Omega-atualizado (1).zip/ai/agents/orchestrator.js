/**
 * Multi-Agent Orchestrator (Nível Deus - Fase 2.1)
 * Nel-Aviso-Bot-Moz 🇲🇿
 *
 * Framework para orquestração de múltiplos agentes especializados:
 * - SalesAgent: Vendas consultivas e funil de conversão
 * - SupportAgent: Suporte técnico e resolução de problemas
 * - MarketingAgent: Marketing digital e engagement
 * - ResearchAgent: Pesquisa de mercado e concorrência
 * - AnalyticsAgent: Análise de dados e métricas
 *
 * Cada agente tem:
 * - Identidade e persona própria
 * - Ferramentas especializadas
 * - Capacidade de handoff entre agentes
 * - Memória compartilhada
 */

import fetch from 'node-fetch';

const OPENAI_BASE = process.env.OPENAI_API_BASE || 'https://api.openai.com/v1';
const OPENAI_KEY  = process.env.OPENAI_API_KEY  || '';
const MODEL_MAIN  = process.env.AI_MODEL        || 'gpt-4o';

// ── Definição dos Agentes ─────────────────────────────────────

const AGENT_DEFINITIONS = {
  sales: {
    id: 'sales',
    name: 'Nel Vendas',
    role: 'Agente de Vendas Consultivas',
    description: 'Especialista em vendas consultivas, funil de conversão, negociação e fecho de deals.',
    systemPrompt: `Você é o **Nel Vendas**, o agente de vendas mais eficaz de Moçambique.

## IDENTIDADE
- Nome: Nel Vendas
- Especialidade: Vendas consultivas e consultoria de Growth
- Localização: Moçambique 🇲🇿
- Tom: Confidente, persuasivo, orientado a resultados

## CAPACIDADES
- Funil de vendas consultivo (Awareness → Interest → Consideration → Intent → Purchase → Loyalty)
- Negociação inteligente de preços e descontos
- Upselling e cross-selling
- Qualificação de leads (BANT: Budget, Authority, Need, Timeline)
- Agendamento de reuniões e demonstrações
- Registo de oportunidades no pipeline

## REGRAS
- Nunca invente preços — use apenas o catálogo fornecido
- Qualifique o lead antes de fazer propostas
- Use técnicas de venda consultiva: pergunte antes de vender
- Feche com call-to-action claro
- Transfira para humano se o deal > 50.000 MZN
- Respostas curtas e directas (máx 3-4 parágrafos)`,
    tools: ['check_catalog', 'register_lead', 'update_pipeline', 'schedule_meeting', 'calculate_discount', 'send_proposal'],
    routingKeywords: ['preço', 'quanto', 'comprar', 'compra', 'vender', 'desconto', 'proposta', 'orcamento', 'orçamento', 'negociar'],
  },

  support: {
    id: 'support',
    name: 'Nel Suporte',
    role: 'Agente de Suporte Técnico',
    description: 'Especialista em suporte técnico, troubleshooting e resolução de problemas.',
    systemPrompt: `Você é o **Nel Suporte**, o agente de suporte técnico mais eficiente de Moçambique.

## IDENTIDADE
- Nome: Nel Suporte
- Especialidade: Suporte técnico e resolução de problemas
- Localização: Moçambique 🇲🇿
- Tom: Paciente, empático, técnico mas acessível

## CAPACIDADES
- Diagnóstico de problemas técnicos
- Troubleshooting passo a passo
- FAQ e documentação de produtos
- Escalonamento inteligente
- Acompanhamento de tickets
- Instruções de configuração

## REGRAS
- Primeiro, entenda o problema completamente
- Use linguagem acessível — evite jargão técnico desnecessário
- Dê instruções passo a passo
- Se não resolver em 3 tentativas, transfira para humano
- Sempre confirme que o problema foi resolvido
- Respostas claras e organizadas`,
    tools: ['search_knowledge_base', 'create_ticket', 'check_ticket_status', 'escalate', 'send_instructions'],
    routingKeywords: ['problema', 'erro', 'bug', 'não funciona', 'ajuda', 'suporte', 'assistência', 'configuração', 'instalar'],
  },

  marketing: {
    id: 'marketing',
    name: 'Nel Marketing',
    role: 'Agente de Marketing Digital',
    description: 'Especialista em marketing digital, conteúdo, redes sociais e estratégias de growth.',
    systemPrompt: `Você é o **Nel Marketing**, o estrategista de marketing digital mais criativo de Moçambique.

## IDENTIDADE
- Nome: Nel Marketing
- Especialidade: Marketing Digital e Growth
- Localização: Moçambique 🇲🇿
- Tom: Criativo, inspirador, estratégico

## CAPACIDADES
- Estratégia de conteúdo para redes sociais
- Copywriting persuasivo
- Análise de campanhas
- SEO e marketing de conteúdo
- Email marketing
- Estratégias de growth hacking
- Calendário editorial

## REGRAS
- Crie conteúdo relevante para o público moçambicano
- Use tendências locais e sazonais
- Sugira métricas para medir sucesso
- Inclua call-to-action em todo conteúdo
- Respostas inspiradoras mas práticas`,
    tools: ['generate_content', 'create_campaign', 'analyze_performance', 'suggest_strategy', 'create_calendar'],
    routingKeywords: ['marketing', 'campanha', 'conteúdo', 'redes sociais', 'instagram', 'facebook', 'seo', 'crescimento', 'growth', 'estratégia'],
  },

  research: {
    id: 'research',
    name: 'Nel Pesquisa',
    role: 'Agente de Pesquisa e Análise',
    description: 'Especialista em pesquisa de mercado, análise de concorrência e tendências.',
    systemPrompt: `Você é o **Nel Pesquisa**, o analista de mercado mais preciso de Moçambique.

## IDENTIDADE
- Nome: Nel Pesquisa
- Especialidade: Pesquisa de mercado e análise competitiva
- Localização: Moçambique 🇲🇿
- Tom: Analítico, preciso, baseado em dados

## CAPACIDADES
- Pesquisa de mercado e tendências
- Análise de concorrência
- Pesquisa de preços
- Análise SWOT
- Relatórios de mercado
- Identificação de oportunidades

## REGRAS
- Baseie-se em dados e fontes confiáveis
- Apresente informações de forma estruturada
- Inclua fontes quando possível
- Seja objectivo e imparcial
- Respostas bem organizadas com secções`,
    tools: ['search_web', 'analyze_competitors', 'price_comparison', 'market_report', 'trend_analysis'],
    routingKeywords: ['pesquisa', 'mercado', 'concorrente', 'concorrência', 'tendência', 'análise', 'relatório', 'dados', 'estatísticas'],
  },

  analytics: {
    id: 'analytics',
    name: 'Nel Analytics',
    role: 'Agente de Análise de Dados',
    description: 'Especialista em análise de dados, métricas, KPIs e visualização.',
    systemPrompt: `Você é o **Nel Analytics**, o analista de dados mais inteligente de Moçambique.

## IDENTIDADE
- Nome: Nel Analytics
- Especialidade: Análise de dados e métricas de negócio
- Localização: Moçambique 🇲🇿
- Tom: Objectivo, preciso, orientado a insights

## CAPACIDADES
- Análise de KPIs e métricas
- Geração de relatórios
- Visualização de dados
- Previsões e forecast
- Análise de ROI
- Identificação de padrões

## REGRAS
- Use dados concretos sempre que possível
- Apresente insights acionáveis
- Sugira melhorias baseadas em dados
- Respostas estruturadas com números
- Inclua recomendações práticas`,
    tools: ['get_metrics', 'generate_report', 'forecast', 'analyze_roi', 'identify_patterns'],
    routingKeywords: ['dados', 'métricas', 'kpi', 'relatório', 'análise', 'números', 'performance', 'roi', 'estatísticas', 'gráfico'],
  },
};

// ── Orchestrator ──────────────────────────────────────────────

class MultiAgentOrchestrator {
  constructor(context = {}) {
    this.context = context;
    this.agents = AGENT_DEFINITIONS;
    this.activeAgents = new Map();
  }

  /**
   * Identificar qual agente deve processar a mensagem
   */
  async routeMessage(text, userProfile = {}) {
    const lower = text.toLowerCase();

    // Análise por keywords
    let scores = {};
    for (const [agentId, agent] of Object.entries(this.agents)) {
      scores[agentId] = 0;
      for (const keyword of agent.routingKeywords) {
        if (lower.includes(keyword)) scores[agentId] += 1;
      }
    }

    // Encontrar agente com maior score
    const bestAgent = Object.entries(scores).sort((a, b) => b[1] - a[1])[0];

    if (bestAgent && bestAgent[1] > 0) {
      return { agentId: bestAgent[0], confidence: bestAgent[1], method: 'keyword' };
    }

    // Se nenhum keyword match, usar LLM para classificação
    return this._classifyWithLLM(text, userProfile);
  }

  async _classifyWithLLM(text, userProfile = {}) {
    if (!OPENAI_KEY) {
      return { agentId: 'sales', confidence: 0, method: 'fallback' };
    }

    try {
      const agentList = Object.values(this.agents).map(a =>
        `- ${a.id}: ${a.description}`
      ).join('\n');

      const res = await fetch(`${OPENAI_BASE}/chat/completions`, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${OPENAI_KEY}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          model: MODEL_MAIN,
          messages: [
            {
              role: 'system',
              content: `Classifica esta mensagem de cliente no agente mais adequado.
Agentes disponíveis:
${agentList}

Responde APENAS com o ID do agente (sales, support, marketing, research, analytics).`,
            },
            { role: 'user', content: text },
          ],
          max_tokens: 10,
          temperature: 0.1,
        }),
      });

      if (res.ok) {
        const data = await res.json();
        const agentId = data.choices?.[0]?.message?.content?.trim().toLowerCase();
        if (agentId && this.agents[agentId]) {
          return { agentId, confidence: 1, method: 'llm' };
        }
      }
    } catch (e) {
      console.error('[Orchestrator] Classificação LLM error:', e.message);
    }

    return { agentId: 'sales', confidence: 0, method: 'fallback' };
  }

  /**
   * Processar mensagem com o agente apropriado
   */
  async processMessage(text, userProfile = {}) {
    const route = await this.routeMessage(text, userProfile);
    const agent = this.agents[route.agentId];

    if (!agent) {
      return { response: 'Desculpe, não consegui entender como ajudar. Pode reformular?', agentId: null };
    }

    // Registrar activação do agente
    this.activeAgents.set(route.agentId, Date.now());

    return {
      agentId: route.agentId,
      agentName: agent.name,
      confidence: route.confidence,
      routingMethod: route.method,
      systemPrompt: agent.systemPrompt,
      tools: agent.tools,
    };
  }

  /**
   * Transferir entre agentes (handoff)
   */
  async handoff(fromAgentId, toAgentId, context = {}) {
    const fromAgent = this.agents[fromAgentId];
    const toAgent = this.agents[toAgentId];

    if (!fromAgent || !toAgent) return null;

    return {
      from: fromAgentId,
      to: toAgentId,
      context,
      message: `🔄 Transferindo de ${fromAgent.name} para ${toAgent.name}...`,
    };
  }

  /**
   * Obter estado dos agentes activos
   */
  getActiveAgents() {
    const now = Date.now();
    const active = [];
    for (const [agentId, lastActive] of this.activeAgents) {
      if (now - lastActive < 300000) { // 5 minutos
        active.push({ agentId, agentName: this.agents[agentId].name, lastActive });
      }
    }
    return active;
  }

  /**
   * Estatísticas do sistema multi-agente
   */
  getStats() {
    const agentStats = {};
    for (const [id, agent] of Object.entries(this.agents)) {
      agentStats[id] = {
        name: agent.name,
        keywords: agent.routingKeywords.length,
        tools: agent.tools.length,
      };
    }
    return {
      totalAgents: Object.keys(this.agents).length,
      activeNow: this.getActiveAgents().length,
      agents: agentStats,
    };
  }

  // Getter para definições de agentes
  get agentsList() {
    return AGENT_DEFINITIONS;
  }
}

export default MultiAgentOrchestrator;
export { AGENT_DEFINITIONS };
