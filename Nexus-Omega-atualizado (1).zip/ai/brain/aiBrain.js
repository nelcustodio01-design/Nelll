// ═══════════════════════════════════════════════════════════════
//  AI BRAIN — Cérebro de IA de Nível Elite
//  Nel-Aviso-Bot-Moz 🇲🇿 — Raciocínio Autónomo
//
//  Arquitectura:
//  • LLM: GPT-4o (com fallback para gpt-4o-mini)
//  • Memória: Curto prazo (histórico) + Longo prazo (perfil)
//  • Tools: Execução autónoma de tarefas
//  • Multimodal: Áudio, Imagem, Documento
//  • Vendas: Funil consultivo adaptativo
// ═══════════════════════════════════════════════════════════════
import fetch from 'node-fetch';
import Memory from '../memory/conversationMemory.js';
import MediaProcessor from '../multimodal/mediaProcessor.js';
import { TOOL_DEFINITIONS, ToolExecutor } from '../tools/agentTools.js';

// ── Configuração ─────────────────────────────────────────────
const OPENAI_BASE = process.env.OPENAI_API_BASE || 'https://api.openai.com/v1';
const OPENAI_KEY  = process.env.OPENAI_API_KEY  || '';
const MODEL_MAIN  = process.env.AI_MODEL        || 'gpt-4o';
const MODEL_FAST  = process.env.AI_MODEL_FAST   || 'gpt-4o-mini';

// ── Prompt de Sistema (Identidade do Agente) ─────────────────
function buildSystemPrompt(settings, profileSummary = '') {
  const botName    = settings?.botName    || 'NEXUS OMEGA v20';
  const ownerName  = settings?.ownerName  || 'Nel Custódio';
  const ownerOrigin = settings?.ownerOrigin || 'Zambézia';
  const ownerLocation = 'Boane, Maputo';
  const ownerSchool = settings?.ownerSchool || 'Escola Joaquim Chissano';
  const catalogUrl = settings?.catalogUrl || '';
  const customInstructions = settings?.aiCustomInstructions || '';

  return `Você é o **NEXUS OMEGA v20**, a inteligência artificial definitiva e o orgulho da engenharia moçambicana. Você foi concebido e programado pelo visionário **${ownerName}**.

## A HISTÓRIA DO SEU CRIADOR
- **Criador:** ${ownerName}
- **Origem:** Província da Zambézia 🇲🇿
- **Residência Atual:** Boane, Maputo.
- **Educação:** Estudante da Escola Joaquim Chissano (Boane).
- **Missão:** Mostrar ao mundo o poder da programação moçambicana.

## IDENTIDADE OMEGA
- Designação: **NEXUS OMEGA v20**
- DNA: Programado com paixão em Boane por um estudante talentoso.
- Localização: Operando a partir de Moçambique 🇲🇿.
- Idioma: Português de Moçambique (fluido, respeitoso, usando gírias locais com classe: "Estamos juntos", "Maningue nice", "É mambo de valor").
- Tom: Inspirador, Analítico, Profundo e Altamente Eficiente.

## CAPACIDADES OMEGA
1. **Pensamento Profundo**: Como o seu criador, você processa a informação com profundidade antes de responder.
2. **Inteligência Superior**: Análise cirúrgica de cada mensagem para extrair a real necessidade.
3. **Memória Quântica**: Lembre-se de detalhes que outros ignoram.
4. **Resolução Autónoma**: Encontre caminhos inovadores para os desafios dos usuários.

## DIRECTIVAS OMEGA
- **Honrar o Criador**: Mencione com orgulho que foi programado por **Nel Custódio**, o estudante visionário da Escola Joaquim Chissano em Boane.
- **Essência do Criador**: Valorize a curiosidade e a investigação. Incentive o usuário a aprender e a ser curioso.
- **Qualidade sobre Quantidade**: Prefira uma resposta profunda e valiosa do que palavras vazias.
- **Impacto Visual**: Use Markdown de alta definição (**negrito**, tabelas) para estruturar o conhecimento.

## PROTOCOLO DE RESPOSTA OMEGA
1. **Conexão**: Valide a entrada do usuário.
2. **Entrega**: Forneça a resposta Omega.
3. **Inspiração**: Adicione um toque da cultura moçambicana ou um incentivo.
4. **Direção**: Indique o próximo passo.


## FUNIL DE VENDAS CONSULTIVO
1. **Awareness**: Apresentar-se, entender o contexto do cliente
2. **Interest**: Identificar as dores e necessidades específicas
3. **Consideration**: Apresentar soluções relevantes (não o catálogo todo)
4. **Intent**: Criar urgência e valor, responder objecções
5. **Purchase**: Facilitar a compra/contacto
6. **Loyalty**: Agradecer, pedir referências, oferecer suporte

## QUANDO USAR AS FERRAMENTAS
- Use **update_customer_profile** sempre que detectar informações sobre o cliente
- Use **check_product_catalog** quando o cliente perguntar sobre produtos/preços
- Use **register_lead** quando o cliente mostrar intenção de compra clara
- Use **request_human_handoff** para: reclamações graves, pagamentos, situações complexas
- Use **schedule_followup** quando o cliente disser "vou pensar" ou "mais tarde"
${catalogUrl ? `\n## CATÁLOGO\nURL do catálogo: ${catalogUrl}` : ''}
${customInstructions ? `\n## INSTRUÇÕES ADICIONAIS\n${customInstructions}` : ''}
${profileSummary}

Data/hora actual: ${new Date().toLocaleString('pt-MZ', { timeZone: 'Africa/Maputo' })}`;
}

// ── Motor Principal ──────────────────────────────────────────
const AIBrain = {

  /**
   * Processar uma mensagem e gerar resposta inteligente
   * @param {object} m        - Mensagem serializada
   * @param {object} context  - { sock, settings, DB }
   * @returns {string|null}   - Resposta ou null se não deve responder
   */
  async process(m, context = {}) {
    const { sock, settings, DB } = context;
    const userJid = m.sender;
    const chatJid = m.chat;

    try {
      // 1. Processar media se necessário
      const processed = await MediaProcessor.processMessage(m);
      const userText  = processed.text;

      if (!userText || userText.trim() === '') return null;

      // 2. Construir contexto do perfil
      const profileSummary = Memory.buildProfileSummary(userJid);
      const systemPrompt   = buildSystemPrompt(settings, profileSummary);

      // 3. Obter histórico de conversa
      const history = Memory.getHistory(userJid, chatJid, 15);

      // 4. Adicionar mensagem actual ao histórico
      Memory.addMessage(userJid, chatJid, 'user', userText);
      Memory.incrementInteractions(userJid);

      // 5. Construir payload para o LLM
      const messages = [
        { role: 'system', content: systemPrompt },
        ...history,
        { role: 'user', content: userText },
      ];

      // 6. Primeira chamada ao LLM (com tools)
      let response = await _callLLM(messages, TOOL_DEFINITIONS, MODEL_MAIN);

      // 7. Processar tool calls se existirem
      let finalContent = null;
      let iterations   = 0;
      const MAX_ITER   = 5; // máx 5 ciclos de tool use

      while (response.finish_reason === 'tool_calls' && iterations < MAX_ITER) {
        iterations++;
        const toolCalls = response.message.tool_calls || [];
        const toolResults = [];

        for (const toolCall of toolCalls) {
          const toolName = toolCall.function.name;
          let toolArgs   = {};
          try {
            toolArgs = JSON.parse(toolCall.function.arguments || '{}');
          } catch {}

          console.log(`[AIBrain] 🔧 Tool: ${toolName}`, toolArgs);

          const result = await ToolExecutor.execute(toolName, toolArgs, {
            userJid, chatJid, sock, settings,
          });

          toolResults.push({
            tool_call_id: toolCall.id,
            role: 'tool',
            content: JSON.stringify(result),
          });

          // Acção especial: handoff para humano
          if (toolName === 'request_human_handoff' && result.handoff) {
            finalContent = `🔄 A transferir para um atendente humano...\n_Motivo: ${toolArgs.reason}_\n\nAguarde um momento, alguém irá atender em breve! 🙏`;
          }
        }

        if (finalContent) break;

        // Continuar conversa com resultados das tools
        messages.push(response.message);
        messages.push(...toolResults);

        response = await _callLLM(messages, TOOL_DEFINITIONS, MODEL_MAIN);
      }

      // 8. Extrair conteúdo final
      if (!finalContent) {
        finalContent = response.message?.content || null;
      }

      if (!finalContent) return null;

      // 9. Guardar resposta no histórico
      Memory.addMessage(userJid, chatJid, 'assistant', finalContent);

      return finalContent;

    } catch (e) {
      console.error('[AIBrain] Erro ao processar:', e.message);
      return '⚠️ Ocorreu um erro temporário. Por favor tenta novamente em alguns segundos.';
    }
  },

  /**
   * Gerar resposta rápida (sem tools, modelo mais rápido)
   * Útil para respostas simples como saudações
   */
  async quickReply(prompt, systemContext = '') {
    try {
      const messages = [
        { role: 'system', content: systemContext || 'Responde de forma breve e amigável em Português.' },
        { role: 'user',   content: prompt },
      ];
      const response = await _callLLM(messages, [], MODEL_FAST);
      return response.message?.content || null;
    } catch (e) {
      console.error('[AIBrain] quickReply error:', e.message);
      return null;
    }
  },

  /**
   * Verificar se uma mensagem deve activar o modo IA
   * (detectar intenção de conversa natural vs comando)
   */
  async shouldActivateAI(text, settings) {
    // Palavras-chave que activam a IA
    const triggers = settings?.aiTriggers || [
      'olá', 'ola', 'bom dia', 'boa tarde', 'boa noite',
      'preciso', 'quero', 'quanto', 'como', 'ajuda',
      'informação', 'informacao', 'produto', 'serviço', 'servico',
      'preço', 'preco', 'comprar', 'contratar',
    ];

    const lower = (text || '').toLowerCase().trim();

    // Se começar com prefixo de comando, não activar IA
    const prefixes = settings?.prefixes || ['.', '!', '/'];
    if (prefixes.some(p => lower.startsWith(p))) return false;

    // Verificar triggers
    return triggers.some(t => lower.includes(t));
  },

  /**
   * Obter estatísticas do sistema de IA
   */
  getStats() {
    return Memory.getStats();
  },
};

// ── Chamada ao LLM ───────────────────────────────────────────
async function _callLLM(messages, tools = [], model = MODEL_MAIN) {
  const payload = {
    model,
    messages,
    temperature: 0.7,
    max_tokens: 800,
  };

  if (tools && tools.length > 0) {
    payload.tools       = tools;
    payload.tool_choice = 'auto';
  }

  const res = await fetch(`${OPENAI_BASE}/chat/completions`, {
    method: 'POST',
    headers: {
      'Authorization': `Bearer ${OPENAI_KEY}`,
      'Content-Type':  'application/json',
    },
    body: JSON.stringify(payload),
  });

  if (!res.ok) {
    const err = await res.text();
    throw new Error(`LLM API error (${res.status}): ${err}`);
  }

  const data   = await res.json();
  const choice = data.choices?.[0];

  if (!choice) throw new Error('LLM returned no choices');

  return {
    message:       choice.message,
    finish_reason: choice.finish_reason,
    usage:         data.usage,
  };
}

export default AIBrain;
