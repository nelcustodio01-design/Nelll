// ═══════════════════════════════════════════════════════════════
//  AI MODULE — Ponto de Entrada do Cérebro de IA
//  Nel-Aviso-Bot-Moz 🇲🇿
// ═══════════════════════════════════════════════════════════════
export { default as AIBrain }    from './brain/aiBrain.js';
export { default as Memory }     from './memory/conversationMemory.js';
export { default as MediaProc }  from './multimodal/mediaProcessor.js';
export { TOOL_DEFINITIONS, ToolExecutor } from './tools/agentTools.js';
