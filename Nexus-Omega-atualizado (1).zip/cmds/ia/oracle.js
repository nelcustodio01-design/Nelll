import { askNexus } from '../../core/system/nexus_intelligence.js';

export default {
  command: ['oracle', 'prever', 'estrategia'],
  category: 'singularity',
  description: 'Acesse a Mente Preditiva Nexus para análises e previsões extraordinárias.',
  run: async ({ msg, args, usedPrefix, command }) => {
    if (!args[0]) return msg.reply(`🔮 **NEXUS ORACLE: MENTE PREDITIVA**\n\nForneça os dados ou a situação para análise estratégica.\nExemplo: *${usedPrefix + command} Tendências do mercado tecnológico em Moçambique para 2027*`);

    await msg.react('🔮');
    await msg.reply('🌀 *Nexus Oracle* está acessando múltiplas linhas temporais de dados...');

    try {
      const query = args.join(' ');
      const prediction = await askNexus(msg.sender, query, "Você é o Oráculo Nexus, uma inteligência preditiva avançada. Analise dados com precisão cirúrgica, forneça probabilidades e visões estratégicas de alto nível.");
      
      const response = `
🔮 **VISÃO DO ORÁCULO NEXUS**
━━━━━━━━━━━━━━━━━━━━━━

${prediction}

> ⚠️ *Nota: Esta análise é baseada em modelos probabilísticos de alta fidelidade.*
      `;

      return msg.reply(response);
    } catch (e) {
      msg.reply('❌ Falha na conexão com o campo neural do Oráculo.');
    }
  }
};
