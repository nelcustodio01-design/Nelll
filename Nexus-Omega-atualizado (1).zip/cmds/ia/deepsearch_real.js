import axios from 'axios';

export default {
  command: ['deepsearch', 'pesquisa-profunda', 'estudar'],
  category: 'ia',
  description: 'Realiza uma busca técnica e científica profunda na rede Nexus.',
  run: async ({ msg, args, usedPrefix, command }) => {
    const query = args.join(' ');
    if (!query) return msg.reply(`🔍 **NEXUS DEEP SEARCH**\n\nUso: *${usedPrefix + command} [tema complexo]*\nExemplo: *${usedPrefix + command} Como funciona a criptografia quântica?*`);

    await msg.react('🔍');
    await msg.reply('🔍 *Nexus Deep Search:* Acedendo a bases de dados científicas e académicas...');

    try {
      // Usando uma API de busca profunda (Perplexity ou similar via proxy)
      const url = `https://api.vreden.web.id/api/ai/deepsearch?query=${encodeURIComponent(query)}`;
      const response = await axios.get(url);
      
      const result = response.data?.result || "A pesquisa não retornou dados técnicos suficientes.";

      const report = `
🔍 **RELATÓRIO DE PESQUISA PROFUNDA**
━━━━━━━━━━━━━━━━━━━━━━

${result}

> 📚 *Fonte: Nexus Academic Grid V14*
      `;

      return msg.reply(report);
    } catch (e) {
      msg.reply('❌ Falha ao conectar com o motor de busca profunda.');
    }
  }
};
