import settings from '#settings';
import DB from '#db';
export default {
  command: ['sql', 'query', 'database'],
  category: 'ia',
  description: 'Gerar query SQL com IA',
  async run({ msg, sock, args, text }) {
    const query = args.join(' ');
    if (!query) return msg.reply('⚠️ Usa: .sql <texto>\n\n📌 Exemplo: .sql como funciona o WhatsApp?');
    await msg.reply(`🤖 A pensar...\n\n🧠 IA: _sql_\n📝 Query: _${query}_\n⏳ Aguarde...`);
  },
};
