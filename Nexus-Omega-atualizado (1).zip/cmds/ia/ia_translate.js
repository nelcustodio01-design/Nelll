import settings from '#settings';
import DB from '#db';
export default {
  command: ['traduziria', 'aitranslate', 'translateia'],
  category: 'ia',
  description: 'Traduzir texto com IA',
  async run({ msg, sock, args, text }) {
    const query = args.join(' ');
    if (!query) return msg.reply('⚠️ Usa: .traduziria <texto>\n\n📌 Exemplo: .traduziria como funciona o WhatsApp?');
    await msg.reply(`🤖 A pensar...\n\n🧠 IA: _traduziria_\n📝 Query: _${query}_\n⏳ Aguarde...`);
  },
};
