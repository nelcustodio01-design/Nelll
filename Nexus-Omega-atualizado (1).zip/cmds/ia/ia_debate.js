import settings from '#settings';
import DB from '#db';
export default {
  command: ['debate', 'debater', 'discussao'],
  category: 'ia',
  description: 'Simular debate entre duas IAs',
  async run({ msg, sock, args, text }) {
    const query = args.join(' ');
    if (!query) return msg.reply('⚠️ Usa: .debate <texto>\n\n📌 Exemplo: .debate como funciona o WhatsApp?');
    await msg.reply(`🤖 A pensar...\n\n🧠 IA: _debate_\n📝 Query: _${query}_\n⏳ Aguarde...`);
  },
};
