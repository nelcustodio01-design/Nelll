import settings from '#settings';
import DB from '#db';
export default {
  command: ['icone', 'icon', 'iconegen'],
  category: 'criativo',
  description: 'Gerar icones',
  async run({ msg, sock, args, text }) {
    const query = args.join(' ');
    if (!query) return msg.reply('⚠️ Usa: .icone <descricao>\n\n📌 Exemplo: .icone um gato astronauta');
    await msg.reply(`🎨 A criar: _icone_\n\n📝 Descricao: _${query}_\n⏳ Aguarde...`);
  },
};
