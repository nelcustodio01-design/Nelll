import settings from '#settings';
import DB from '#db';
export default {
  command: ['pattern', 'padrao', 'textura'],
  category: 'criativo',
  description: 'Gerar padrao/texture',
  async run({ msg, sock, args, text }) {
    const query = args.join(' ');
    if (!query) return msg.reply('⚠️ Usa: .pattern <descricao>\n\n📌 Exemplo: .pattern um gato astronauta');
    await msg.reply(`🎨 A criar: _pattern_\n\n📝 Descricao: _${query}_\n⏳ Aguarde...`);
  },
};
