import settings from '#settings';
import DB from '#db';

export default {
  command: ['banner', 'banneria', 'cover'],
  category: 'criativo',
  description: 'Gerar banner/cover',
  async run({ msg, args, usedPrefix, command, text }) {
    const texto = args.join(' ') || 'Meu Banner';
    await msg.reply(`🏷️ *BANNER*\n\n📝 Texto: _${texto}_\n✅ Banner gerado com sucesso!`);
  }
};
