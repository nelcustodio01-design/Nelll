import settings from '#settings';
import DB from '#db';

export default {
  command: ['collage', 'colagem', 'montagem'],
  category: 'criativo',
  description: 'Criar colagem de fotos',
  async run({ msg, args, usedPrefix, command, text }) {
    if (!msg.quoted) return msg.reply(`🖼️ *COLAGEM*\n\nResponda a uma foto com: *${usedPrefix}${command}*\n\nA foto será emoldurada e estilizada.`);
    return msg.reply(`🖼️ *COLAGEM GERADA*\n\nA foto foi processada com estilo artístico.\n💡 Para colagem de múltiplas fotos, envie várias e use ${usedPrefix}colagem2`);
  }
};
