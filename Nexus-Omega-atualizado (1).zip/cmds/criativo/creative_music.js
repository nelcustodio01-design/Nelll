import settings from '#settings';
import DB from '#db';
export default {
  command: ['musicagen', 'gerarmusica', 'criarmusica'],
  category: 'criativo',
  description: 'Gerar musica com IA',
  async run({ msg, sock, args, text }) {
    const query = args.join(' ');
    if (!query) return msg.reply('⚠️ Usa: .musicagen <descricao>\n\n📌 Exemplo: .musicagen um gato astronauta');
    await msg.reply(`🎨 A criar: _musicagen_\n\n📝 Descricao: _${query}_\n⏳ Aguarde...`);
  },
};
