/**
 * 🎴 ROBWAIFU — Roubar personagem de outro utilizador
 * Corrigido: removida restrição isPremiumBot, adicionado import fs
 */
import db from '#db';
import fs from 'fs';

const charactersFilePath = './core/characters.json';

async function loadCharacters() {
  try {
    const data = await fs.promises.readFile(charactersFilePath, 'utf-8');
    return JSON.parse(data);
  } catch {
    return {};
  }
}

function flattenCharacters(structure) {
  return Object.values(structure).flatMap(s => Array.isArray(s.characters) ? s.characters : []);
}

function getSeriesNameByCharacter(structure, id) {
  for (const [series, data] of Object.entries(structure)) {
    if (Array.isArray(data.characters) && data.characters.some(c => (c.id || c) === id)) return series;
  }
  return 'Desconhecido';
}

export default {
  command: ['robwaifu', 'roubarwaifu'],
  category: 'gacha',
  description: 'Roubar um personagem do harem de outro utilizador 🎴',
  run: async ({ msg, sock, usedPrefix, command }) => {
    try {
      const chat = db.getChat(msg.chat);
      if (chat.adminonly || !chat.gacha) {
        return msg.reply(
          `ꕥ Os comandos de *Gacha* estão desativados neste grupo.\n\n` +
          `Um *administrador* pode ativá-los com o comando:\n» *${usedPrefix}gacha on*`
        );
      }

      db.setCreate('chat_users', [msg.chat, msg.sender], 'lastrobwaifu', 0);
      db.setCreate('chat_users', [msg.chat, msg.sender], 'robVictims', {});

      let userData = db.getChatUser(msg.chat, msg.sender);
      if (!Array.isArray(userData.characters)) userData.characters = [];
      if (userData.robVictims && typeof userData.robVictims === 'string') {
        try { userData.robVictims = JSON.parse(userData.robVictims); } catch { userData.robVictims = {}; }
      }
      if (!userData.robVictims) userData.robVictims = {};

      const now = Date.now();
      const cooldown = 3 * 60 * 60 * 1000;
      const nextAllowed = userData.lastrobwaifu || 0;

      if (nextAllowed > 0 && now < nextAllowed) {
        const timeLeft = Math.ceil((nextAllowed - now) / 1000);
        const h = Math.floor(timeLeft / 3600);
        const m_ = Math.floor((timeLeft % 3600) / 60);
        const s = timeLeft % 60;
        let timeText = '';
        if (h > 0) timeText += `${h}h `;
        if (m_ > 0) timeText += `${m_}m `;
        if (s > 0 || !timeText) timeText += `${s}s`;
        return msg.reply(`ꕥ Deve esperar *${timeText.trim()}* para usar *${usedPrefix}${command}* novamente.`);
      }

      const target = msg.mentionedJid?.[0] || msg.quoted?.sender || null;
      if (!target) return msg.reply(`❀ Por favor, cita ou menciona o utilizador a quem queres roubar uma waifu.`);
      if (target === msg.sender) return msg.reply(`ꕥ Não podes roubar-te a ti mesmo!`);

      const targetUser = db.getChatUser(msg.chat, target);
      const lastCmd = targetUser?.lastCmd || 0;
      if (now - lastCmd < 3600000) {
        const targetName = (db.getUser(target))?.name?.trim() || target.split('@')[0];
        return msg.reply(`ꕥ *${targetName}* esteve ativo recentemente. Só podes roubar waifus se estiver inativo há mais de 1 hora.`);
      }

      const last = userData.robVictims[target];
      if (last && now - last < 24 * 60 * 60 * 1000) {
        const targetName = (db.getUser(target))?.name?.trim() || target.split('@')[0];
        return msg.reply(`ꕥ Já roubaste *${targetName}* hoje. Só podes roubar alguém uma vez a cada 24 horas.`);
      }

      const targetName = (db.getUser(target))?.name?.trim() || target.split('@')[0];
      const robberName = (db.getUser(msg.sender))?.name?.trim() || msg.sender.split('@')[0];

      let victim = db.getChatUser(msg.chat, target);
      if (!Array.isArray(victim.characters) || victim.characters.length === 0) {
        return msg.reply(`ꕥ *${targetName}* não tem waifus que possas roubar.`);
      }

      const success = Math.random() < 0.4;
      userData.lastrobwaifu = now + cooldown;
      db.setChatUser(msg.chat, msg.sender, 'lastrobwaifu', userData.lastrobwaifu);

      if (!success) {
        return msg.reply(`ꕥ A tentativa de roubo falhou! *${targetName}* defendeu a sua waifu heroicamente. 🛡️`);
      }

      userData.robVictims[target] = now;
      db.setChatUser(msg.chat, msg.sender, 'robVictims', userData.robVictims);

      const victimFavorite = victim.favorite;
      const stealableCharacters = victim.characters.filter(id => id !== victimFavorite);
      if (stealableCharacters.length === 0) {
        return msg.reply(`ꕥ *${targetName}* só tem o seu favorito protegido. Não podes roubá-lo!`);
      }

      const stolenId = stealableCharacters[Math.floor(Math.random() * stealableCharacters.length)];
      const structure = await loadCharacters();
      const allCharacters = flattenCharacters(structure);
      const jsonChar = allCharacters.find(c => (c.id || c) === stolenId);
      const charKey = msg.chat + '__' + stolenId;
      const characterData = { name: jsonChar?.name || `ID:${stolenId}`, value: jsonChar?.value || 100, votes: 0, user: msg.sender, claimedAt: now };

      db.setCharacter(charKey, characterData);
      victim.characters = victim.characters.filter(id => id !== stolenId);
      db.setChatUser(msg.chat, target, 'characters', victim.characters);

      if (!userData.characters.includes(stolenId)) {
        userData.characters.push(stolenId);
        db.setChatUser(msg.chat, msg.sender, 'characters', userData.characters);
      }

      if (victim.favorite === stolenId) {
        db.setChatUser(msg.chat, target, 'favorite', '');
        db.setUser(target, 'favorite', '');
      }

      const source = getSeriesNameByCharacter(structure, stolenId);
      await msg.reply(
        `❀ *${robberName}* roubou *${characterData.name}* (_${source}_) do harem de *${targetName}*! 🎉`
      );
    } catch (e) {
      return msg.reply(`❌ Erro ao executar *${usedPrefix}${command}*: ${e.message}`);
    }
  }
};
