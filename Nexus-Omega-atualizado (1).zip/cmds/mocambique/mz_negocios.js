import settings from '#settings';
import DB from '#db';
export default {
  command: ['negocios', 'empresa', 'emprego'],
  category: 'mocambique',
  description: 'Oportunidades de negocio e emprego',
  async run({ msg, sock, args, text }) {
    await msg.reply(`🇲🇿 A buscar: _negocios_\n\n⏳ Aguarde...`);
  },
};
