import settings from '#settings';
import DB from '#db';
export default {
  command: ['educacao', 'escola', 'universidade'],
  category: 'mocambique',
  description: 'Informacoes de educacao',
  async run({ msg, sock, args, text }) {
    await msg.reply(`🇲🇿 A buscar: _educacao_\n\n⏳ Aguarde...`);
  },
};
