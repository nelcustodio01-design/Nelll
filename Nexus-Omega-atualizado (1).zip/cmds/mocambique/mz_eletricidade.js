import settings from '#settings';
import DB from '#db';
export default {
  command: ['eletricidade', 'luz', 'edms'],
  category: 'mocambique',
  description: 'Estado da rede electrica',
  async run({ msg, sock, args, text }) {
    await msg.reply(`🇲🇿 A buscar: _eletricidade_\n\n⏳ Aguarde...`);
  },
};
