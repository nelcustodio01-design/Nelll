// Feriados Nacionais de Moçambique — Nel-Aviso-Bot-Moz 🇲🇿
const FERIADOS = [
  { data: '01-01', nome: 'Ano Novo', emoji: '🎆', tipo: 'nacional' },
  { data: '03-02', nome: 'Dia dos Heróis Moçambicanos', emoji: '🦁', tipo: 'nacional' },
  { data: '07-04', nome: 'Dia da Mulher Moçambicana', emoji: '👩', tipo: 'nacional' },
  { data: '18-04', nome: 'Sexta-Feira Santa', emoji: '✝️', tipo: 'religioso', variavel: true },
  { data: '01-05', nome: 'Dia do Trabalhador', emoji: '⚙️', tipo: 'nacional' },
  { data: '25-06', nome: 'Dia da Independência Nacional', emoji: '🇲🇿', tipo: 'nacional' },
  { data: '07-09', nome: 'Dia da Vitória', emoji: '🏆', tipo: 'nacional' },
  { data: '25-09', nome: 'Dia das Forças Armadas', emoji: '🎖️', tipo: 'nacional' },
  { data: '04-10', nome: 'Dia da Paz e Reconciliação', emoji: '🕊️', tipo: 'nacional' },
  { data: '25-12', nome: 'Natal / Dia da Família', emoji: '🎄', tipo: 'religioso' },
];

function diasAteProximo(diaStr) {
  const now = new Date();
  const ano = now.getFullYear();
  const [dia, mes] = diaStr.split('-').map(Number);
  let data = new Date(ano, mes - 1, dia);
  if (data < now) data = new Date(ano + 1, mes - 1, dia);
  const diff = Math.ceil((data - now) / (1000 * 60 * 60 * 24));
  return { data, diff };
}

function formatarData(data) {
  return data.toLocaleDateString('pt-PT', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' });
}

export default {
  command: ['feriados', 'feriado', 'diasnacionais', 'mocambique'],
  category: 'mocambique',
  description: 'Ver feriados nacionais de Moçambique e próximos feriados. 🇲🇿',
  run: async ({ msg, args, usedPrefix, command }) => {
    try {
      const sub = args[0]?.toLowerCase();

      if (sub === 'proximos' || sub === 'próximos' || sub === 'next' || !sub) {
        // Próximos 3 feriados
        const agora = new Date();
        const comDias = FERIADOS.map(f => ({ ...f, ...diasAteProximo(f.data) }));
        const proximos = comDias.sort((a, b) => a.diff - b.diff).slice(0, 4);

        let txt = `🇲🇿 *PRÓXIMOS FERIADOS NACIONAIS DE MOÇAMBIQUE*\n\n`;
        for (const f of proximos) {
          const urgente = f.diff === 0 ? ' ← *HOJE!* 🎉' : f.diff === 1 ? ' ← *AMANHÃ!*' : '';
          txt += `${f.emoji} *${f.nome}*${urgente}\n`;
          txt += `   📅 ${formatarData(f.data)}\n`;
          txt += `   ⏳ ${f.diff === 0 ? 'É hoje!' : `Faltam ${f.diff} dias`}\n\n`;
        }

        txt += `📌 Usa *${usedPrefix + command} todos* para ver todos os feriados`;
        return msg.reply(txt);
      }

      if (sub === 'todos' || sub === 'all' || sub === 'lista') {
        let txt = `🇲🇿 *FERIADOS NACIONAIS DE MOÇAMBIQUE*\n\n`;
        for (const f of FERIADOS) {
          const [dia, mes] = f.data.split('-');
          txt += `${f.emoji} *${f.nome}*\n   📅 ${dia}/${mes}${f.variavel ? ' _(data variável)_' : ''}\n\n`;
        }
        txt += `_Fonte: INATEL / Governo de Moçambique_\n_Nel-Aviso-Bot-Moz 🇲🇿_`;
        return msg.reply(txt);
      }

      if (sub === 'hoje' || sub === 'today') {
        const hoje = new Date();
        const diaHoje = String(hoje.getDate()).padStart(2, '0');
        const mesHoje = String(hoje.getMonth() + 1).padStart(2, '0');
        const chave = `${diaHoje}-${mesHoje}`;
        const feriado = FERIADOS.find(f => f.data === chave);
        if (feriado) {
          return msg.reply(
            `${feriado.emoji} *HOJE É FERIADO NACIONAL!*\n\n` +
            `🇲🇿 *${feriado.nome}*\n\n` +
            `_Bom feriado a todos os moçambicanos! 🇲🇿_`
          );
        }
        return msg.reply(`✅ Hoje não é feriado nacional em Moçambique.\n\nUsa *${usedPrefix + command} proximos* para ver os próximos feriados.`);
      }

      return msg.reply(
        `🇲🇿 *FERIADOS DE MOÇAMBIQUE*\n\n` +
        `▸ *${usedPrefix + command}* — Próximos feriados\n` +
        `▸ *${usedPrefix + command} hoje* — Verificar se hoje é feriado\n` +
        `▸ *${usedPrefix + command} todos* — Ver todos os feriados`
      );
    } catch (e) {
      return msg.reply(`❧ Erro: ${e.message}`);
    }
  }
};
