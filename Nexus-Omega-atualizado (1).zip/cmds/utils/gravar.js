/**
 * gravar.js — desativado: comandos movidos para falar.js
 * Use .notar / .notavoz / .gravar
 */
export default {
  command: ['_gravar_old'],
  category: 'utilidades',
  description: 'Desativado (ver falar.js)',
  run: async ({ msg }) => {}
};
