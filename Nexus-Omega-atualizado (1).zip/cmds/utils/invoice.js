/**
 * .invoice - Gerador de Faturas Profissionais
 * Cria faturas em PDF com numeração automática
 * Uso: .invoice [cliente] | [itens] | [valor]
 */

import { Document, Packer, Paragraph, Table, TableCell, TextRun, AlignmentType, WidthType } from 'docx';
import { writeFileSync } from 'fs';
import { join } from 'path';
import { randomBytes } from 'crypto';

export default {
  command: ['invoice-adv', 'fatura-recibo', 'recibo-digital'],
  category: 'utils',
  description: 'Gera faturas profissionais em Word',
  usage: '.invoice [cliente] | [itens] | [valor]',
  ownerOnly: true,
  run: async function (msg, sock, args, text, usedPrefix, command, isOwner) {
    try {
      if (!isOwner) {
        return msg.reply('❌ Este comando é exclusivo para donos do bot!');
      }

      if (!args.length) {
        return msg.reply(
          '💰 *Gerador de Faturas*\n\n' +
          'Uso: `.invoice [cliente] | [itens] | [valor total]`\n\n' +
          'Exemplo:\n' +
          '`.invoice João Silva | Consultoria (5h x 500 MZN) | 2500`'
        );
      }

      const fullText = args.join(' ');
      const [cliente, itens, valor] = fullText.split('|').map(s => s.trim());

      if (!cliente || !itens || !valor) {
        return msg.reply('❌ Formato inválido! Use: `.invoice [cliente] | [itens] | [valor]`');
      }

      const processing = await msg.reply(
        '📄 Gerando fatura...\n' +
        `Cliente: ${cliente}\n` +
        `Valor: ${valor} MZN\n\n` +
        'Por favor, aguarde...'
      );

      try {
        const invoicePath = await generateInvoice(cliente, itens, valor);

        if (!invoicePath) {
          return msg.reply('❌ Erro ao gerar fatura!');
        }

        await sock.sendMessage(msg.chat, {
          document: { url: `file://${invoicePath}` },
          mimetype: 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
          fileName: `Fatura_${cliente.replace(/\s+/g, '_')}_${Date.now()}.docx`,
          caption:
            `✅ *Fatura Gerada com Sucesso!*\n\n` +
            `👤 Cliente: ${cliente}\n` +
            `💰 Valor: ${valor} MZN\n` +
            `📅 Data: ${new Date().toLocaleDateString('pt-MZ')}\n` +
            `🤖 Gerador: Nel-Aviso-Bot`
        }, { quoted: msg });

        await sock.sendMessage(msg.chat, { delete: processing.key });

      } catch (error) {
        console.error('Erro ao gerar fatura:', error);
        return msg.reply('❌ Erro ao processar fatura!');
      }

    } catch (error) {
      console.error('Erro em invoice:', error);
      msg.reply('❌ Erro ao processar comando invoice!');
    }
  }
};

async function generateInvoice(cliente, itens, valor) {
  try {
    const invoiceNum = Math.floor(Math.random() * 10000) + 1000;
    const dataAtual = new Date();
    const dataVencimento = new Date(dataAtual.getTime() + 30 * 24 * 60 * 60 * 1000);

    const doc = new Document({
      sections: [{
        children: [
          new Paragraph({
            text: 'NEL-AVISO-BOT',
            heading: 'Heading1',
            alignment: AlignmentType.CENTER,
            spacing: { after: 200 },
            run: new TextRun({
              bold: true,
              size: 28,
              color: '1F4E78'
            })
          }),
          new Paragraph({
            text: 'FATURA PROFISSIONAL',
            alignment: AlignmentType.CENTER,
            spacing: { after: 400 },
            run: new TextRun({
              italics: true,
              size: 20,
              color: '666666'
            })
          }),
          new Table({
            width: { size: 100, type: WidthType.PERCENTAGE },
            rows: [
              {
                cells: [
                  new TableCell({ children: [new Paragraph('Nº Fatura')], shading: { fill: 'E8F0F8' } }),
                  new TableCell({ children: [new Paragraph(`${invoiceNum}`)], shading: { fill: 'F5F5F5' } }),
                  new TableCell({ children: [new Paragraph('Data')], shading: { fill: 'E8F0F8' } }),
                  new TableCell({ children: [new Paragraph(dataAtual.toLocaleDateString('pt-MZ'))], shading: { fill: 'F5F5F5' } })
                ]
              },
              {
                cells: [
                  new TableCell({ children: [new Paragraph('Cliente')], shading: { fill: 'E8F0F8' } }),
                  new TableCell({ children: [new Paragraph(cliente)], columnSpan: 3, shading: { fill: 'F5F5F5' } })
                ]
              },
              {
                cells: [
                  new TableCell({ children: [new Paragraph('Vencimento')], shading: { fill: 'E8F0F8' } }),
                  new TableCell({ children: [new Paragraph(dataVencimento.toLocaleDateString('pt-MZ'))], columnSpan: 3, shading: { fill: 'F5F5F5' } })
                ]
              }
            ]
          }),
          new Paragraph({ text: '', spacing: { after: 400 } }),
          new Paragraph({ text: 'Descrição dos Serviços:', bold: true, spacing: { after: 200 } }),
          new Paragraph({ text: itens, spacing: { after: 400 } }),
          new Table({
            width: { size: 100, type: WidthType.PERCENTAGE },
            rows: [
              {
                cells: [
                  new TableCell({ children: [new Paragraph('Subtotal')], shading: { fill: 'E8F0F8' } }),
                  new TableCell({ children: [new Paragraph(`${valor} MZN`)], shading: { fill: 'F5F5F5' } })
                ]
              },
              {
                cells: [
                  new TableCell({ children: [new Paragraph('Impostos (0%)')], shading: { fill: 'E8F0F8' } }),
                  new TableCell({ children: [new Paragraph('0 MZN')], shading: { fill: 'F5F5F5' } })
                ]
              },
              {
                cells: [
                  new TableCell({ children: [new Paragraph({ text: 'TOTAL', bold: true })], shading: { fill: '1F4E78' } }),
                  new TableCell({ children: [new Paragraph({ text: `${valor} MZN`, bold: true, run: new TextRun({ color: 'FFFFFF' }) })], shading: { fill: '1F4E78' } })
                ]
              }
            ]
          }),
          new Paragraph({ text: '', spacing: { after: 600 } }),
          new Paragraph({ text: 'Obrigado pela sua confiança!', alignment: AlignmentType.CENTER, italics: true, spacing: { after: 200 } }),
          new Paragraph({
            text: `Gerado por Nel-Aviso-Bot • ${new Date().toLocaleTimeString('pt-MZ')}`,
            alignment: AlignmentType.CENTER,
            run: new TextRun({ size: 16, color: '999999' })
          })
        ]
      }]
    });

    const fileName = `invoice_${randomBytes(4).toString('hex')}.docx`;
    const filePath = join(process.cwd(), 'temp', fileName);
    const buffer = await Packer.toBuffer(doc);
    writeFileSync(filePath, buffer);

    return filePath;

  } catch (error) {
    console.error('Erro ao criar fatura:', error);
    return null;
  }
}
