/**
 * .hashtag-gerador - Gerador de Hashtags para Redes Sociais
 * Gera hashtags relevantes e otimizadas
 * Uso: .hashtags [tema]
 */

const hashtagDatabase = {
  'tecnologia': ['#Tech', '#Inovação', '#Software', '#IA', '#Programação', '#WebDevelopment', '#CyberSegurança', '#CloudComputing', '#DevOps', '#Startup', '#TechNews', '#Desenvolvimento', '#Coding', '#Python', '#JavaScript'],
  'moçambique': ['#Moçambique', '#Moz', '#Maputo', '#Mozambique', '#MozambiqueForever', '#ProudMozambican', '#AfricaRising', '#SomosMoçambique', '#Lusófono', '#SADC', '#MozambiqueTravel', '#MozambiqueFood', '#MozambiqueMusic', '#MozambiqueArt'],
  'negócios': ['#Negócios', '#Empreendedorismo', '#StartUp', '#Inovação', '#Sucesso', '#Empresário', '#Liderança', '#Crescimento', '#Oportunidade', '#Investimento', '#Marketing', '#Vendas', '#Estratégia', '#Networking', '#B2B'],
  'marketing': ['#Marketing', '#SocialMedia', '#Digital', '#Branding', '#Publicidade', '#Conteúdo', '#SEO', '#SEM', '#Influencer', '#Viral', '#Engagement', '#Community', '#Estratégia', '#Campanha', '#Criatividade'],
  'educação': ['#Educação', '#Aprendizagem', '#Estudo', '#Conhecimento', '#Aprender', '#Escola', '#Universidade', '#Formação', '#Desenvolvimento', '#Habilidades', '#Mentoria', '#Coaching', '#Cursos', '#Online', '#Sucesso'],
  'saúde': ['#Saúde', '#Bem-estar', '#Fitness', '#Nutrição', '#Exercício', '#Medicina', '#Wellness', '#Vida', '#Cuidado', '#Prevenção', '#Mental', '#Psicologia', '#Yoga', '#Meditação', '#Energia'],
  'viagem': ['#Viagem', '#Turismo', '#Aventura', '#Explorar', '#Mundo', '#Destino', '#Férias', '#Mochila', '#Fotografia', '#Experiência', '#Natureza', '#Praia', '#Montanha', '#Cultura', '#Descoberta'],
  'moda': ['#Moda', '#Estilo', '#Roupa', '#Beleza', '#Tendência', '#Outfit', '#Fashion', '#Elegância', '#Acessórios', '#Inspiração', '#Lookbook', '#Desfile', '#Designer', '#Luxo', '#Estilista'],
  'comida': ['#Comida', '#Gastronomia', '#Receita', '#Culinária', '#Delicioso', '#Restaurante', '#Cozinha', '#Sabor', '#Ingrediente', '#Prato', '#Fotografia', '#Foodie', '#Chef', '#Buffet', '#Tradicional'],
  'música': ['#Música', '#Canção', '#Artista', '#Ritmo', '#Som', '#Melodia', '#Banda', '#Concerto', '#Festival', '#Playlist', '#Genero', '#Produtor', '#Estúdio', '#Gravação', '#Sucesso']
};

export default {
  command: ['hashtags', 'hashtag', 'tags'],
  category: 'utils',
  description: 'Gera hashtags otimizadas para redes sociais',
  usage: '.hashtags [tema]',
  run: async function (msg, sock, args, text, usedPrefix, command) {
    try {
      if (!args.length) {
        const temas = Object.keys(hashtagDatabase).join(', ');
        return msg.reply(
          '🏷️ *Gerador de Hashtags*\n\n' +
          'Uso: `.hashtags [tema]`\n\n' +
          `Temas disponíveis:\n${temas}\n\n` +
          'Exemplo: `.hashtags tecnologia`'
        );
      }

      const tema = args[0].toLowerCase();

      if (!hashtagDatabase[tema]) {
        const temas = Object.keys(hashtagDatabase).join(', ');
        return msg.reply(`❌ Tema "${tema}" não encontrado!\n\nTemas: ${temas}`);
      }

      const hashtags = hashtagDatabase[tema];
      const selecionados = [];
      const copia = [...hashtags];

      for (let i = 0; i < Math.min(15, hashtags.length); i++) {
        const idx = Math.floor(Math.random() * copia.length);
        selecionados.push(copia[idx]);
        copia.splice(idx, 1);
      }

      const populares = selecionados.slice(0, 5).join(' ');
      const medios = selecionados.slice(5, 10).join(' ');
      const nicho = selecionados.slice(10, 15).join(' ');
      const todosHashtags = selecionados.join(' ');

      await sock.sendMessage(msg.chat, {
        text:
          `✅ *Hashtags Geradas!*\n\n` +
          `🏷️ *Tema: ${tema.toUpperCase()}*\n\n` +
          `⭐ *Populares (Alto Alcance):*\n${populares}\n\n` +
          `📊 *Médios (Bom Engajamento):*\n${medios}\n\n` +
          `🎯 *Nicho (Específico):*\n${nicho}\n\n` +
          `📋 *Todos os Hashtags:*\n${todosHashtags}\n\n` +
          `📈 Total: ${selecionados.length} hashtags\n` +
          `💡 Dica: Use os populares para alcance, nicho para engajamento!\n` +
          `⏰ ${new Date().toLocaleTimeString('pt-MZ')}`
      }, { quoted: msg });

    } catch (error) {
      console.error('Erro em hashtag_gerador:', error);
      msg.reply('❌ Erro ao processar comando hashtags!');
    }
  }
};
