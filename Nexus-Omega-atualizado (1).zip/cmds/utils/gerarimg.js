/**
 * 🎨 GERAR IMAGEM — IA Image Generator com múltiplos fallbacks
 * Corrigido: removido conflito de alias 'dalle' e 'imagine'
 */
import fetch from 'node-fetch';

export default {
  command: ['gerarimg', 'gerarimagem', 'imgai', 'aiimg', 'criarimg'],
  category: 'ia',
  description: 'Gerar imagens com Inteligência Artificial! 🎨',
  run: async ({ msg, sock, args, usedPrefix, command }) => {
    const text = args.join(' ').trim();
    if (!text) {
      return msg.reply(
        `🎨 *GERAR IMAGEM COM IA* 🎨\n\n` +
        `▸ Descreve a imagem que queres criar!\n\n` +
        `✏️ *Exemplos:*\n` +
        `▸ *${usedPrefix}${command} um gato astronauta no espaço*\n` +
        `▸ *${usedPrefix}${command} mapa de Moçambique em estilo pixel*\n` +
        `▸ *${usedPrefix}${command} uma praia tropical ao pôr do sol*\n` +
        `▸ *${usedPrefix}${command} robô a dançar na lua*\n\n` +
        `💡 Quanto mais detalhado, melhor o resultado!`
      );
    }

    const { key } = await sock.sendMessage(msg.chat, {
      text: `🎨 *Gerando imagem...*\n▸ Prompt: _${text}_\n⏳ Aguarda...`
    }, { quoted: msg });
    await msg.react('🎨');

    let imageUrl = null;

    // 1. Pollinations AI (gratuito, muito estável)
    try {
      imageUrl = `https://image.pollinations.ai/prompt/${encodeURIComponent(text)}?width=1024&height=1024&nologo=true&seed=${Date.now()}`;
      const testRes = await fetch(imageUrl, { method: 'HEAD', timeout: 12000 });
      if (!testRes.ok) imageUrl = null;
    } catch { imageUrl = null; }

    // 2. API siputzx text2img
    if (!imageUrl) {
      try {
        const res = await fetch(`https://api.siputzx.my.id/api/s/text2img?prompt=${encodeURIComponent(text)}`, { timeout: 15000 });
        const json = await res.json();
        if (json?.status && json?.data) imageUrl = typeof json.data === 'string' ? json.data : (json.data.url || json.data.image);
      } catch {}
    }

    // 3. API delirius
    if (!imageUrl) {
      try {
        const res = await fetch(`${global.APIs.delirius.url}/ia/dalle?text=${encodeURIComponent(text)}`, { timeout: 15000 });
        const json = await res.json();
        if (json?.status && json?.data) imageUrl = typeof json.data === 'string' ? json.data : (json.data.url || json.data.image);
      } catch {}
    }

    // 4. API yuki
    if (!imageUrl) {
      try {
        const res = await fetch(`${global.APIs.yuki.url}/ai/dalle?text=${encodeURIComponent(text)}&key=${global.APIs.yuki.key}`, { timeout: 15000 });
        const json = await res.json();
        if (json?.status && json?.result) imageUrl = typeof json.result === 'string' ? json.result : (json.result.url || json.result.image);
      } catch {}
    }

    // 5. API vreden
    if (!imageUrl) {
      try {
        const res = await fetch(`${global.APIs.vreden.url}/api/ai/dalle3?query=${encodeURIComponent(text)}`, { timeout: 15000 });
        const json = await res.json();
        if (json?.result) imageUrl = typeof json.result === 'string' ? json.result : (json.result.url || json.result.image);
      } catch {}
    }

    if (!imageUrl) {
      return sock.sendMessage(msg.chat, {
        text: '❌ Não foi possível gerar a imagem. Reformula o prompt e tenta novamente.', edit: key
      }, { quoted: msg });
    }

    await sock.sendMessage(msg.chat, {
      image: { url: imageUrl },
      caption: `🎨 *Imagem Gerada com IA*\n\n▸ Prompt: _${text}_\n\n💡 *${usedPrefix}gerarimg <prompt>* para criar mais!`
    }, { quoted: msg });
    await msg.react('✅');
  }
};
