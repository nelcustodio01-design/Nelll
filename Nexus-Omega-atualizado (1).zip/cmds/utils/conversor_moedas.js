/**
 * .conversor-moedas - Conversor de Moedas em Tempo Real
 * Converte valores entre moedas
 * Uso: .conversor [valor] [moeda origem] [moeda destino]
 */

const taxasFixas = {
  'USD': 1,
  'EUR': 0.92,
  'GBP': 0.79,
  'JPY': 149.5,
  'CNY': 7.24,
  'INR': 83.12,
  'BRL': 4.97,
  'ZAR': 18.5,
  'MZN': 63.5,
  'AOA': 826,
  'BWP': 13.5,
  'SZL': 18.2,
  'NAD': 18.5,
  'LSL': 18.2,
  'MUR': 43.5,
  'KES': 130.5,
  'TZS': 2500,
  'UGX': 3750,
  'RWF': 1300,
  'ETB': 52.5
};

export default {
  command: ['conversor-adv', 'moeda-tr', 'cambio-real', 'conv-moeda'],
  category: 'utils',
  description: 'Converte valores entre moedas',
  usage: '.conversor [valor] [origem] [destino]',
  run: async function (msg, sock, args, text, usedPrefix, command) {
    try {
      if (!args.length || args.length < 3) {
        const moedas = Object.keys(taxasFixas).join(', ');
        return msg.reply(
          '💱 *Conversor de Moedas*\n\n' +
          'Uso: `.conversor [valor] [origem] [destino]`\n\n' +
          `Moedas: ${moedas}\n\n` +
          'Exemplos:\n' +
          '• `.conversor 100 USD MZN`\n' +
          '• `.conversor 50 EUR BRL`\n' +
          '• `.conversor 1000 MZN USD`'
        );
      }

      const valor = parseFloat(args[0]);
      const origem = args[1].toUpperCase();
      const destino = args[2].toUpperCase();

      if (isNaN(valor) || valor <= 0) {
        return msg.reply('❌ Valor inválido!');
      }

      if (!taxasFixas[origem] || !taxasFixas[destino]) {
        return msg.reply(`❌ Moeda não encontrada!\n\nMoedas: ${Object.keys(taxasFixas).join(', ')}`);
      }

      const processing = await msg.reply(
        `💱 Convertendo ${valor} ${origem} para ${destino}...\n\n` +
        'Por favor, aguarde...'
      );

      try {
        const resultado = await converterMoeda(valor, origem, destino);

        if (!resultado) {
          return msg.reply('❌ Erro ao converter!');
        }

        const taxa = (resultado.valor_destino / valor).toFixed(4);

        await sock.sendMessage(msg.chat, {
          text:
            `✅ *Conversão Realizada!*\n\n` +
            `💰 *Valores:*\n` +
            `${valor} ${origem} = ${resultado.valor_destino.toFixed(2)} ${destino}\n\n` +
            `📊 *Detalhes:*\n` +
            `• Taxa: 1 ${origem} = ${taxa} ${destino}\n` +
            `• Valor original: ${valor} ${origem}\n` +
            `• Valor convertido: ${resultado.valor_destino.toFixed(2)} ${destino}\n` +
            `• Diferença: ${(resultado.valor_destino - valor).toFixed(2)}\n\n` +
            `📅 Atualizado: ${new Date().toLocaleDateString('pt-MZ')}\n` +
            `⏰ ${new Date().toLocaleTimeString('pt-MZ')}`
        }, { quoted: msg });

        await sock.sendMessage(msg.chat, { delete: processing.key });

      } catch (error) {
        console.error('Erro ao converter:', error);
        return msg.reply('❌ Erro ao processar conversão!');
      }

    } catch (error) {
      console.error('Erro em conversor:', error);
      msg.reply('❌ Erro ao processar comando conversor!');
    }
  }
};

async function converterMoeda(valor, origem, destino) {
  try {
    const taxa_origem = taxasFixas[origem] || 1;
    const taxa_destino = taxasFixas[destino] || 1;
    const valor_usd = valor / taxa_origem;
    const valor_destino = valor_usd * taxa_destino;

    return {
      valor_original: valor,
      moeda_origem: origem,
      valor_destino: valor_destino,
      moeda_destino: destino,
      taxa: taxa_destino / taxa_origem
    };

  } catch (error) {
    console.error('Erro ao calcular conversão:', error);
    return null;
  }
}
