/**
 * 🎙️ TRADUTOR DE ÁUDIO — Transcreve áudio e traduz o conteúdo
 * Corrigido: reescrito completamente com APIs funcionais
 */
import fetch from 'node-fetch';
import axios from 'axios';
import fs from 'fs';
import FormData from 'form-data';

export default {
  command: ['traduzir-audio', 'audiotr', 'audiotrad', 'transcrev'],
  category: 'utilidades',
  description: 'Transcreve áudio e traduz para o idioma desejado 🎙️🌍',
  run: async ({ msg, sock, args, usedPrefix, command }) => {
    // Verifica se há áudio citado
    let audioMsg = null;
    if (msg.quoted) {
      const qMsg = msg.quoted.message;
      if (qMsg?.audioMessage || qMsg?.voiceMessage || qMsg?.pttMessage ||
          qMsg?.documentMessage?.mimetype?.startsWith('audio')) {
        audioMsg = msg.quoted;
      }
    }

    if (!audioMsg) {
      return msg.reply(
        `🎙️🌍 *TRADUTOR DE ÁUDIO*\n\n` +
        `▸ Responde a uma mensagem de voz/áudio!\n\n` +
        `▸ Uso: *${usedPrefix}${command} [idioma-destino]*\n\n` +
        `▸ Exemplos:\n` +
        `  _(cita um áudio)_ *${usedPrefix}${command}* — transcreve em PT\n` +
        `  _(cita um áudio)_ *${usedPrefix}${command} en* — transcreve e traduz para EN\n\n` +
        `▸ Idiomas: pt, en, es, fr, de, it, ja, zh, ru, ar`
      );
    }

    const targetLang = args[0]?.toLowerCase() || null;
    await msg.react('🎙️');

    const { key } = await sock.sendMessage(msg.chat, {
      text: '🎙️ A transcrever o áudio...'
    }, { quoted: msg });

    try {
      const buffer = await sock.downloadMediaMessage(audioMsg);
      if (!buffer || buffer.length < 100) {
        return sock.sendMessage(msg.chat, { text: '❌ Não foi possível baixar o áudio.', edit: key }, { quoted: msg });
      }

      let transcribed = null;

      // API 1: siputzx audio2text
      try {
        const form = new FormData();
        form.append('audio', buffer, { filename: 'audio.ogg', contentType: 'audio/ogg' });
        const res = await axios.post('https://api.siputzx.my.id/api/s/audio2text', form, {
          headers: form.getHeaders(), timeout: 20000
        });
        if (res.data?.status && res.data?.data) transcribed = res.data.data;
      } catch {}

      // API 2: Delirius audio2text
      if (!transcribed) {
        try {
          const form = new FormData();
          form.append('audio', buffer, { filename: 'audio.ogg', contentType: 'audio/ogg' });
          const res = await axios.post(`${global.APIs.delirius.url}/tools/audio2text`, form, {
            headers: form.getHeaders(), timeout: 20000
          });
          if (res.data?.status && (res.data?.data || res.data?.result)) {
            transcribed = res.data.data || res.data.result;
          }
        } catch {}
      }

      if (!transcribed) {
        return sock.sendMessage(msg.chat, {
          text: '❌ Não foi possível transcrever o áudio. Tenta com um áudio mais claro e curto.', edit: key
        }, { quoted: msg });
      }

      let resposta = `🎙️ *Transcrição:*\n${transcribed}`;

      // Se pediu tradução
      if (targetLang && targetLang !== 'pt') {
        let translated = null;
        try {
          const res = await fetch(
            `https://api.mymemory.translated.net/get?q=${encodeURIComponent(transcribed)}&langpair=auto|${targetLang}`,
            { timeout: 10000 }
          );
          const data = await res.json();
          if (data?.responseData?.translatedText) translated = data.responseData.translatedText;
        } catch {}

        if (translated) {
          resposta += `\n\n🌍 *Tradução (${targetLang.toUpperCase()}):*\n${translated}`;
        }
      }

      await sock.sendMessage(msg.chat, { text: resposta, edit: key }, { quoted: msg });
      await msg.react('✅');
    } catch (e) {
      await msg.react('❌');
      await sock.sendMessage(msg.chat, { text: `❌ Erro: ${e.message}`, edit: key }, { quoted: msg });
    }
  }
};
