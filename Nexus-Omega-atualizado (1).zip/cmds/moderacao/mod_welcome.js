import settings from '#settings';
import DB from '#db';

export default {
  command: ['bemvindo', 'entrada'],
  category: 'moderacao',
  description: 'Mensagem de boas-vindas',
  async run({ msg, args, usedPrefix, command }) {
    const activar = args[0] && args[0].toLowerCase();
    if (!activar) return msg.reply(
      '👋 *BOAS-VINDAS*\n\n' +
      'Uso: *' + usedPrefix + command + ' on/off*\n\n' +
      '• *' + usedPrefix + command + ' on* — Activar\n' +
      '• *' + usedPrefix + command + ' off* — Desactivar'
    );
    if (activar === 'on') return msg.reply('👋 *Boas-vindas ACTIVADA!*\n\nNovos membros serão recebidos automaticamente.');
    if (activar === 'off') return msg.reply('👋 *Boas-vindas DESACTIVADA!*');
    return msg.reply('❌ Use *on* ou *off*');
  }
};
