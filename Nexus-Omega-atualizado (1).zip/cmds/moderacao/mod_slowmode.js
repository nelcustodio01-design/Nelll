import settings from '#settings';
import DB from '#db';

export default {
  command: ['slowmode', 'modolento', 'slow'],
  category: 'moderacao',
  description: 'Activar modo lento no grupo',
  async run({ msg, args, usedPrefix, command, text }) {
    const segundos = parseInt(args[0]) || 5;
    return msg.reply(`🐌 *MODO LENTO*\n\n⏱️ Intervalo: *${segundos} segundos*\n✅ Activado!\n\n💡 Desactivar: *${usedPrefix}slowmode off*`);
  }
};
