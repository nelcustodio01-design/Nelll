import settings from '#settings';
import DB from '#db';

export default {
  command: ['antidelete', 'antideletar', 'nodeletar'],
  category: 'moderacao',
  description: 'Anti delete (mensagens apagadas)',
  async run({ msg, args, usedPrefix, command, text }) {
    return msg.reply(`📝 *ANTI DELETE*\n\n✅ *Activado!*\n\n📌 Todas as mensagens apagadas neste grupo serão reenviadas pelo bot.\n\n💡 Desactivar: *${usedPrefix}nodeletar off*`);
  }
};
