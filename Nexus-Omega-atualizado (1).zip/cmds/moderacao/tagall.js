export default {
  command: ['tagall', 'todos', 'mencionar'],
  category: 'moderacao',
  description: 'Menciona todos os membros do grupo.',
  isAdmin: true,
  run: async ({ msg, sock, participants, text }) => {
    const message = text || "Atenção a todos!";
    const mentions = participants.map(p => p.id);
    
    let report = `📢 **CONVOCAÇÃO NEXUS**\n\n💬 *Mensagem:* ${message}\n\n`;
    
    participants.forEach((p, i) => {
        report += `${i + 1}. @${p.id.split('@')[0]}\n`;
    });

    report += `\n🚀 *Nel-Aviso Singularity V14*`;

    return sock.sendMessage(msg.chat, { 
        text: report, 
        mentions 
    }, { quoted: msg });
  }
};
