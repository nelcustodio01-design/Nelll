import db from '#db';
export default {
  command: ['shop', 'loja', 'inventory', 'inv', 'inventario'],
  category: 'economy',
  description: 'Ver a loja do bot.',
  run: async ({ msg, sock, args, usedPrefix, command, text }) => {
    const chat = db.getChat(msg.chat);
    if (chat.adminonly || !chat.economy) {
      return msg.reply(`ꕥ Los comandos de *Economia* están desactivados en este grupo.\n\nUn *administrador* puede activarlos con o comando:\n» *${usedPrefix}economy on*`);
    }    
    const botId = sock.user.id.split(':')[0] + '@s.whatsapp.net';
    const settings = db.getSettings(botId);
    const currency = settings?.currency
    db.setCreate('chat_users', [msg.chat, msg.sender], 'inventory', {});
    db.setCreate('chat_users', [msg.chat, msg.sender], 'weapons', {});
    db.setCreate('chat_users', [msg.chat, msg.sender], 'tools', {});
    let user = db.getChatUser(msg.chat, msg.sender);
    const users = db.getUser(msg.sender);
    if (user.weapons && typeof user.weapons === 'string') {
      try { user.weapons = JSON.parse(user.weapons); } catch { user.weapons = {}; }
    }
    if (user.tools && typeof user.tools === 'string') {
      try { user.tools = JSON.parse(user.tools); } catch { user.tools = {}; }
    }
    if (user.inventory && typeof user.inventory === 'string') {
      try { user.inventory = JSON.parse(user.inventory); } catch { user.inventory = {}; }
    }    
    const armas = [{ id: 'espada', name: 'Espada', price: 8000, durability: 100, description: 'Para aventura', tipo: 'Combate' }, { id: 'hacha', name: 'Hacha', price: 7500, durability: 100, description: 'Para mazmorra', tipo: 'Combate' }, { id: 'arco', name: 'Arco', price: 7000, durability: 100, description: 'Para caçar', tipo: 'Combate' }];    
    const ferramentas = [{ id: 'pico', name: 'Pico', price: 6500, durability: 100, description: 'Para minerar', tipo: 'Equipo' }, { id: 'vara', name: 'Vara de pescar', price: 6000, durability: 100, description: 'Para pescar', tipo: 'Equipo' }, { id: 'totem', name: 'Totem', price: 4000, durability: 3, description: 'Para ritual', tipo: 'Consumible' }, { id: 'pocion', name: 'Pocion', price: 1500, durability: 1, description: 'Restaura magia', tipo: 'Consumible' }];
    const commandType = command.toLowerCase();
    if (commandType === 'inventory' || commandType === 'inv' || commandType === 'inventario') {
      const userName = users?.name || msg.pushName || 'Usuário';
      let invMessage = `*「✿」Inventario* ◢ ${userName} ◤\n`;
      invMessage += `⛁ Coins totales › *¥${((user.coins || 0) + (user.bank || 0)).toLocaleString()} ${currency}*\n`;
      invMessage += `♡ Saúde › *${user.health || 0}/100*\n`;
      invMessage += `♛ Stamina › *${user.stamina || 0}/100*\n`;
      invMessage += `⸙ Magia › *${user.magic || 0}/100*\n`;
      let hasItems = false;
      if (user.weapons && Object.keys(user.weapons).length > 0) {
        hasItems = true;
        const weaponCount = Object.keys(user.weapons).length;
        invMessage += `\nꕥ Armas › *${weaponCount}*`;
        for (const [id, weapon] of Object.entries(user.weapons)) {
          const armaInfo = armas.find(a => a.id === id);
          if (armaInfo) {
            invMessage += `\n○ ${armaInfo.name} › *${weapon.durability}/${weapon.maxDurability}*`;
          }
        }
      }
      if (user.tools && Object.keys(user.tools).length > 0) {
        hasItems = true;
        const toolCount = Object.keys(user.tools).length;
        invMessage += `\n\n𖢺 Equipo › *${toolCount}*`;
        for (const [id, tool] of Object.entries(user.tools)) {
          const toolInfo = ferramentas.find(t => t.id === id);
          if (toolInfo) {
            invMessage += `\n○ ${toolInfo.name} › *${tool.durability}/${tool.maxDurability}*`;
          }
        }
      }
      const tieneTotem = (user.inventory?.totem || 0) > 0;
      const tienePocion = (user.inventory?.pocion || 0) > 0;
      if (tieneTotem || tienePocion) {
        hasItems = true;
        invMessage += `\n\n𖣺 Consumibles`;
        if (tieneTotem) {
          invMessage += `\n○ Totem › *${user.inventory.totem}*`;
        }
        if (tienePocion) {
          invMessage += `\n○ Pocion › *${user.inventory.pocion}*`;
        }
      }
      if (!hasItems) {
        invMessage += `\n\nTu inventario está vacío.\nCompra items na loja usando: *${usedPrefix}shop*`;
      }
      await sock.sendMessage(msg.chat, { text: invMessage }, { quoted: msg });
      return;
    }
    if (commandType === 'shop' || commandType === 'loja') {
      try {
        const armasDisponibles = armas.filter(item => !user.weapons?.[item.id]);
        const ferramentasDisponibles = ferramentas.filter(item => {
          if (item.id === 'totem' || item.id === 'pocion') {
            return true;
          }
          return !user.tools?.[item.id];
        });
        const itemsDisponibles = [...armasDisponibles, ...ferramentasDisponibles];
        if (itemsDisponibles.length === 0) {
          return msg.reply(`*☆ Item Shop \`≧◠ᴥ◠≦\`*\n\nꕥ Neste momento a loja está fechada por reabastecimiento.\n\n> ꕥ Has comprado todos os objectos disponíveis.`);
        }
        const page = parseInt(args[0]) || 1;
        const porPagina = 10;
        const totalPaginas = Math.ceil(itemsDisponibles.length / porPagina);
        if (page < 1 || page > totalPaginas) {
          return msg.reply(`ꕥ Página inválida. Só há *${totalPaginas}* disponible${totalPaginas > 1 ? 's' : ''}.`);
        }
        const listado = [];
        const itemsPaginados = itemsDisponibles.slice((page - 1) * porPagina, page * porPagina);
        for (const item of itemsPaginados) {
          let descripcion = item.description;
          if (item.id === 'pocion') {
            const magiaActual = user.magic || 0;
            const magiaFaltante = 100 - magiaActual;
            const efecto = magiaFaltante > 0 ? Math.min(magiaFaltante, 100) : 0;
            if (efecto === 0) {
              descripcion = 'Poção mágica';
            } else {
              descripcion = `Restaura ${efecto} pontos de magia (${efecto}/100)`;
            }
          }
          let durabilidadText = '';
          if (item.tipo === 'Consumible') {
            durabilidadText = `ⴵ Usos » *${item.durability}*`;
          } else {
            durabilidadText = `ⴵ Durabilidad » *${item.durability}*`;
          }
          listado.push(`❀ *${item.name}* (${item.tipo}):\n> ⛁ Precio » *¥${item.price.toLocaleString()} ${currency}*\n> ❖ Descripcion » *${descripcion}*\n> ${durabilidadText}`);
        }
        const mensaje = `*☆ Item Shop \`≧◠ᴥ◠≦\`*\n❏ Objectos disponíveis <${itemsDisponibles.length}>:\n\n` + listado.join('\n\n') + `\n\n> • Paginá *${page}* de *${totalPaginas}*`;
        msg.reply(mensaje);
      } catch (e) {
        await msg.reply(`> An unexpected error occurred ao executar o comando *${usedPrefix + command}*. Please try again or contact support if the issue persists.\n> [Erro: *${e.message}*]`);
      }
      return;
    }
    // A lógica de compra agora é gerenciada pelo comando comprar.js independente.
  }
};