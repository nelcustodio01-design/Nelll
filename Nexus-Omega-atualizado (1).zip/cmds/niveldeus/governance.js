/**
 * Comandos de Governança e Dashboard (Nível Deus - Fase 4)
 * Nel-Aviso-Bot-Moz 🇲🇿
 */
import db from '#db';

export default {
  command: ['governance', 'governancao', 'dashboard', 'níveldeus', 'niveldeus'],
  category: 'nível deus',
  description: 'Painel de governança e dashboard do sistema Nível Deus. 🛡️',
  ownerOnly: true,
  run: async ({ msg, sock, args, usedPrefix, command }) => {
    try {
      const sub = args[0]?.toLowerCase();

      if (!sub || sub === 'status' || sub === 'resumo') {
        return msg.reply(
          `🛡️ *PAINEL DE GOVERNANÇA — NÍVEL DEUS*\n\n` +
          `━━━━━━━━━━━━━━━━━━━━\n` +
          `📊 *Fases Implementadas:*\n` +
          `✅ Fase 1: Consolidação da Memória\n` +
          `   • Vector Store (embeddings)\n` +
          `   • Grafo de Conhecimento\n` +
          `   • Pipeline de Ingestão\n\n` +
          `✅ Fase 2: Multi-Agente & Ferramentas\n` +
          `   • 5 Agentes Especializados\n` +
          `   • Ferramentas Avançadas\n` +
          `   • Orquestrador Inteligente\n\n` +
          `✅ Fase 3: Proatividade & Predição\n` +
          `   • Predição de Intenção\n` +
          `   • Follow-up Proactivo\n` +
          `   • Testes A/B\n` +
          `   • Aprendizagem Contínua\n\n` +
          `✅ Fase 4: HITL & Governança\n` +
          `   • Auditoria de IA\n` +
          `   • Gestão de Excepções\n` +
          `   • Aprovações Humanas\n` +
          `   • Regras de Compliance\n\n` +
          `━━━━━━━━━━━━━━━━━━━━\n` +
          `💡 Use:\n` +
          `• *${usedPrefix + command} audit* — Registo de auditoria\n` +
          `• *${usedPrefix + command} regras* — Ver regras activas\n` +
          `• *${usedPrefix + command} excepções* — Excepções pendentes\n` +
          `• *${usedPrefix + command} aprovacoes* — Aprovações pendentes\n` +
          `• *${usedPrefix + command} relatorio* — Relatório de governança`
        );
      }

      if (sub === 'audit' || sub === 'auditoria') {
        const limit = parseInt(args[1]) || 10;
        const recent = db.prepare(`
          SELECT * FROM governance_audit ORDER BY created_at DESC LIMIT ?
        `).all(limit);

        if (recent.length === 0) {
          return msg.reply('📋 *REGISTO DE AUDITORIA*\n\nNenhum evento registado ainda.');
        }

        let text = `📋 *REGISTO DE AUDITORIA* (últimos ${recent.length})\n\n`;
        for (const evt of recent) {
          text += `▸ [${evt.severity.toUpperCase()}] ${evt.event_type}\n`;
          text += `  ${evt.user_jid || 'sistema'} • ${new Date(evt.created_at).toLocaleString('pt-MZ', { timeZone: 'Africa/Maputo' })}\n`;
        }
        return msg.reply(text);
      }

      if (sub === 'regras' || sub === 'rules') {
        const rules = db.prepare('SELECT * FROM governance_rules WHERE enabled = 1').all();
        if (rules.length === 0) {
          return msg.reply('📏 *REGRAS DE GOVERNANÇA*\n\nNenhuma regra activa.');
        }
        let text = `📏 *REGRAS DE GOVERNANÇA ACTIVAS*\n\n`;
        for (const r of rules) {
          text += `▸ *${r.rule_name}* (${r.rule_type})\n  Acção: ${r.action}\n`;
        }
        return msg.reply(text);
      }

      if (sub === 'excepções' || sub === 'exceções' || sub === 'exceptions') {
        const pending = db.prepare('SELECT * FROM exceptions_log WHERE resolved = 0 ORDER BY created_at DESC LIMIT 10').all();
        if (pending.length === 0) {
          return msg.reply('✅ *EXCEPÇÕES*\n\nNenhuma excepção pendente.');
        }
        let text = `⚠️ *EXCEPÇÕES PENDENTES*\n\n`;
        for (const e of pending) {
          text += `▸ [${e.severity.toUpperCase()}] ${e.exception_type}\n`;
          text += `  ID: ${e.id} • ${new Date(e.created_at).toLocaleString('pt-MZ', { timeZone: 'Africa/Maputo' })}\n`;
        }
        return msg.reply(text);
      }

      if (sub === 'aprovacoes' || sub === 'aprovações' || sub === 'approvals') {
        const pending = db.prepare("SELECT * FROM human_approvals WHERE status = 'pending' ORDER BY created_at DESC LIMIT 10").all();
        if (pending.length === 0) {
          return msg.reply('✅ *APROVAÇÕES*\n\nNenhuma aprovação pendente.');
        }
        let text = `🔐 *APROVAÇÕES PENDENTES*\n\n`;
        for (const a of pending) {
          text += `▸ ${a.request_type}\n`;
          text += `  ID: ${a.id} • ${new Date(a.created_at).toLocaleString('pt-MZ', { timeZone: 'Africa/Maputo' })}\n`;
          try { text += `  Dados: ${JSON.parse(a.request_data).description || JSON.stringify(JSON.parse(a.request_data))}\n`; } catch {}
        }
        return msg.reply(text);
      }

      if (sub === 'relatorio' || sub === 'relatório' || sub === 'report') {
        return msg.reply(
          `📊 *RELATÓRIO DE GOVERNANÇA*\n\n` +
          `━━━━━━━━━━━━━━━━━━━━\n` +
          `📋 Audits totais: ${db.prepare('SELECT COUNT(*) as c FROM governance_audit').get()?.c || 0}\n` +
          `⚠️ Excepções pendentes: ${db.prepare('SELECT COUNT(*) as c FROM exceptions_log WHERE resolved = 0').get()?.c || 0}\n` +
          `🔐 Aprovações pendentes: ${db.prepare("SELECT COUNT(*) as c FROM human_approvals WHERE status = 'pending'").get()?.c || 0}\n` +
          `📏 Regras activas: ${db.prepare('SELECT COUNT(*) as c FROM governance_rules WHERE enabled = 1').get()?.c || 0}\n` +
          `🤖 Decisões IA: ${db.prepare("SELECT COUNT(*) as c FROM governance_audit WHERE event_type = 'ai_decision'").get()?.c || 0}\n` +
          `━━━━━━━━━━━━━━━━━━━━\n` +
          `Estado: *SISTEMA OPERACIONAL* ✅`
        );
      }

      return msg.reply(
        `🛡️ *GOVERNANÇA*\n\n` +
        `▸ *${usedPrefix + command} status* — Resumo do sistema\n` +
        `▸ *${usedPrefix + command} audit* — Registo de auditoria\n` +
        `▸ *${usedPrefix + command} regras* — Regras activas\n` +
        `▸ *${usedPrefix + command} excepções* — Excepções\n` +
        `▸ *${usedPrefix + command} aprovacoes* — Aprovações\n` +
        `▸ *${usedPrefix + command} relatorio* — Relatório completo`
      );
    } catch (e) {
      return msg.reply(`❧ Erro: ${e.message}`);
    }
  }
};
