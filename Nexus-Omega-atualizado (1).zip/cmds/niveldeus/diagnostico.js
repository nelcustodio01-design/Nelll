// ═══════════════════════════════════════════════════════════════
//  COMANDO .diagnostico — Diagnóstico completo de estabilidade
//  Nel-Aviso-Bot-Moz 🇲🇿 — Nível Deus Edition
// ═══════════════════════════════════════════════════════════════
import Stability from '../../core/stability.js';
import AutoReconnect from '../../core/autoReconnect.js';
import HumanClone from '../../core/humanClone.js';

export default {
  name: 'diagnostico',
  alias: ['diag', 'stability', 'estabilidade'],
  desc: 'Verificar estabilidade completa do bot',
  category: 'Nível Deus',
  ownerOnly: true,
  async run({ msg, sock, args }) {
    const subcmd = args[0]?.toLowerCase();

    if (subcmd === 'reconnect') {
      // Forçar reconexão
      msg.reply('🔄 A forçar reconexão...');
      try {
        sock.end(undefined, 'manual reconnect').catch(() => {});
        await msg.react('✅');
      } catch (e) {
        await msg.react('❌');
      }
      return;
    }

    if (subcmd === 'clone') {
      // Mostrar perfil do clone humano
      const profile = HumanClone.getProfile();
      await msg.reply(
        `👤 *Perfil do Clone Humano*\n\n` +
        `Horário: ${profile.activeHours.start}h-${profile.activeHours.end}h\n` +
        `Vocabulário: ${profile.vocabCount} palavras\n` +
        `Emojis: ${profile.emojis.length}\n` +
        `Padrões: ${profile.responsePatterns}\n` +
        `Tempo médio: ${profile.avgResponseTime / 1000}s`
      );
      return;
    }

    if (subcmd === 'stats') {
      // Mostrar estatísticas de reply
      const replyStats = Stability.fullDiagnostic(sock, null);
      await msg.reply(Stability.formatDiagnostic(replyStats));
      return;
    }

    if (subcmd === 'repair') {
      // Auto-repair
      const repairs = await Stability.autoRepair(sock, null);
      await msg.reply(
        '🔧 *Auto-Repair*\n\n' +
        (repairs.length > 0 ? repairs.join('\n') : '✅ Tudo está a funcionar correctamente')
      );
      return;
    }

    // Diagnóstico completo
    const diag = Stability.fullDiagnostic(sock, null);
    const reconState = AutoReconnect.getReconnectState();

    const replyText = Stability.formatDiagnostic(diag) +
      `\n\n🔌 *Reconexão*\n` +
      `Tentativas: ${reconState.count}\n` +
      `A reconectar: ${reconState.isReconnecting ? 'SIM' : 'NÃO'}\n` +
      `Sessão preservada: ${reconState.sessionPreserved ? 'SIM' : 'NÃO'}\n` +
      `Falhas consecutivas: ${reconState.consecutiveFailures}\n` +
      `\n💡 Usa \`.diag reconnect\` para forçar reconexão\n` +
      `💡 Usa \`.diag repair\` para auto-reparação`;

    await msg.reply(replyText);
  },
};
