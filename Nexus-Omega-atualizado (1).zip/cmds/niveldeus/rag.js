/**
 * Comando: .rag — Base de Conhecimento RAG
 * Nel-Aviso-Bot-Moz 🇲🇿 — Nível Deus Edition
 */
export default {
  name: 'rag',
  aliases: ['conhecimento', 'knowledge', 'base'],
  category: 'niveldeus',
  desc: 'Perguntar à base de conhecimento ou indexar documentos',
  usage: '.rag <pergunta> | .rag indexar <tipo> <texto/url>',
  ownerOnly: false,
};

export async function execute(sock, msg, store, args) {
  const chatJid = msg.key.remoteJid;
  const senderJid = msg.key.participant || msg.key.remoteJid;

  if (!args[0]) {
    return sock.sendMessage(chatJid, {
      text: `📚 *Base de Conhecimento — Nel-Bot*\n\n` +
        `*Como usar:*\n` +
        `.rag <pergunta> — Perguntar algo\n` +
        `.rag indexar texto <conteúdo> — Adicionar conhecimento\n` +
        `.rag indexar url <url> — Indexar website\n` +
        `.rag indexar ficheiro <caminho> — Indexar ficheiro\n` +
        `.rag stats — Ver estatísticas`,
    });
  }

  // ── Indexar ─────────────────────────────────────────────
  if (args[0] === 'indexar') {
    const subCommand = args[1];
    const content = args.slice(2).join(' ');

    if (subCommand === 'texto' && content) {
      const result = await global.dataIngestion?.ingestEntity(
        'whatsapp', `knowledge:${Date.now()}`, 'knowledge', content,
        { userJid: senderJid }
      );
      if (global.ragEngine) {
        await global.ragEngine.indexDocument('/tmp/rag_input.txt', 'text').catch(() => {
          // Guardar directamente na memória
          global.vectorStore?.addEntity(`user_${Date.now()}`, 'knowledge', content, 'rag').catch(() => {});
        });
      }
      return sock.sendMessage(chatJid, { text: `📚 Conhecimento adicionado!\nTokens: ~${Math.ceil(content.length / 4)}` });
    }

    if (subCommand === 'url' && content) {
      if (!global.ragEngine) return sock.sendMessage(chatJid, { text: '❌ RAG não disponível.' });
      const result = await global.ragEngine.indexURL(content);
      return sock.sendMessage(chatJid, { text: result.success ? `📚 URL indexada! ${result.chunks} chunks.` : `❌ Erro: ${result.error}` });
    }

    return sock.sendMessage(chatJid, { text: '❌ Usa: .rag indexar texto <conteúdo> | .rag indexar url <url>' });
  }

  // ── Estatísticas ────────────────────────────────────────
  if (args[0] === 'stats') {
    const stats = global.ragEngine?.getStats() || {};
    return sock.sendMessage(chatJid, {
      text: `📊 *Estatísticas RAG:*\n` +
        `📚 Documentos: ${stats.documents || 0}\n` +
        `📝 Chunks: ${stats.chunks || 0}\n` +
        `🔤 Tokens: ${stats.tokens || 0}\n` +
        `📋 Tipos: ${stats.types?.map(t => `${t.doc_type}: ${t.c}`).join(', ') || 'Nenhum'}`,
    });
  }

  // ── Perguntar ───────────────────────────────────────────
  const question = args.join(' ');
  if (!global.ragEngine) {
    return sock.sendMessage(chatJid, { text: '❌ Base de conhecimento não disponível.' });
  }

  await sock.sendMessage(chatJid, { text: '🔍 A pesquisar na base de conhecimento...' });

  try {
    const userLang = global.multilingualEngine?.getUserPreferredLang(senderJid) || 'pt';
    const result = await global.ragEngine.query(question, { lang: userLang });

    let response = `📚 *Resposta:*\n${result.answer}`;
    if (result.sources?.length > 0) {
      response += `\n\n*Fontes:* ${result.sources.length} encontradas (confiança: ${Math.round(result.confidence * 100)}%)`;
    }
    return sock.sendMessage(chatJid, { text: response });
  } catch (e) {
    return sock.sendMessage(chatJid, { text: `❌ Erro: ${e.message}` });
  }
}
