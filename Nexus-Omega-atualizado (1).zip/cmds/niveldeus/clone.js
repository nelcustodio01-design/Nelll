// ═══════════════════════════════════════════════════════════════
//  COMANDO .clone — Gerir o modo Clone Humano
//  Nel-Aviso-Bot-Moz 🇲🇿 — Nível Deus Edition
//
//  Subcomandos:
//  .clone status     — Ver estado do clone
//  .clone add        — Adicionar chat ao clone
//  .clone remove     — Remover chat do clone
//  .clone list       — Listar chats clonados
//  .clone off        — Desactivar clone num chat
// ═══════════════════════════════════════════════════════════════
import HumanClone from '../../core/humanClone.js';

// Auto-responder global
const autoResponder = HumanClone.createAutoResponder();

export default {
  name: 'clone',
  alias: ['humano', 'humanc', 'clonehumano'],
  desc: 'Modo Clone Humano — o bot actua como se fosse o utilizador real',
  category: 'Nível Deus',
  ownerOnly: true,
  async run({ msg, sock, args, chatId }) {
    const subcmd = args[0]?.toLowerCase();
    const targetChat = args[1]?.replace('@', '') || chatId;

    switch (subcmd) {
      case 'status': {
        const profile = HumanClone.getProfile();
        const active = autoResponder.list();
        await msg.reply(
          `👤 *Modo Clone Humano*\n\n` +
          `Horário: ${profile.activeHours.start}h-${profile.activeHours.end}h\n` +
          `Vocabulário aprendido: ${profile.vocabCount} palavras\n` +
          `Emojis favoritos: ${profile.emojis.slice(0, 5).join(' ')}\n` +
          `Padrões guardados: ${profile.responsePatterns}\n\n` +
          `Chats clonados: ${active.length}\n` +
          `${active.map(c => `• ${c.split('@')[0]}`).join('\n') || 'Nenhum'}`
        );
        break;
      }

      case 'add': {
        autoResponder.addChat(targetChat);
        await msg.reply(`✅ Chat ${targetChat.split('@')[0]} adicionado ao clone humano.`);
        break;
      }

      case 'remove': {
        autoResponder.removeChat(targetChat);
        await msg.reply(`❌ Chat ${targetChat.split('@')[0]} removido do clone humano.`);
        break;
      }

      case 'list': {
        const active = autoResponder.list();
        if (active.length === 0) {
          await msg.reply('📋 Nenhum chat clonado. Usa `.clone add <jid>` para adicionar.');
        } else {
          await msg.reply(
            `📋 *Chats Clonados*\n\n` +
            active.map((c, i) => `${i + 1}. ${c.split('@')[0]}`).join('\n')
          );
        }
        break;
      }

      case 'off': {
        autoResponder.removeChat(targetChat);
        await msg.reply(`🚫 Clone humano desactivado para ${targetChat.split('@')[0]}.`);
        break;
      }

      default: {
        await msg.reply(
          `👤 *Modo Clone Humano*\n\n` +
          `O bot actua como se fosse o utilizador real, usando o seu\n` +
          `vocabulário, emojis e padrões de resposta.\n\n` +
          `*Subcomandos:*\n` +
          `▸ \`.clone status\` — Ver estado\n` +
          `▸ \`.clone add <jid>\` — Adicionar chat\n` +
          `▸ \`.clone remove <jid>\` — Remover chat\n` +
          `▸ \`.clone list\` — Listar chats\n` +
          `▸ \`.clone off <jid>\` — Desactivar`
        );
        break;
      }
    }
  },
};
