import settings from '#settings';
import DB from '#db';
export default {
  command: ['disk', 'disco', 'armazenamento'],
  category: 'niveldeus',
  description: 'Ver espaco em disco',
  ownerOnly: true,
  async run({ msg, sock, args, text }) {
    await msg.reply(`⚙️ A processar: _disk_\n\n✅ Feito!`);
  },
};
