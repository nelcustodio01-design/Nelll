// ═══════════════════════════════════════════════════════════════
//  COMANDO .segredo — Comunicação encriptada bot-dono
//  Nel-Aviso-Bot-Moz 🇲🇿 — Nível Deus Edition
//
//  Permite ao dono enviar comandos secretos encriptados
//  que ninguém consegue ler na tela do WhatsApp
// ═══════════════════════════════════════════════════════════════
import crypto from 'crypto';

function getEncryptionKey() {
  const source = process.env.NEXUS_SECRET_KEY || process.env.SESSION_SECRET;
  if (!source) throw new Error('Configura SESSION_SECRET ou NEXUS_SECRET_KEY no ambiente.');
  return Buffer.from(crypto.hkdfSync(
    'sha256',
    Buffer.from(source, 'utf8'),
    Buffer.alloc(0),
    Buffer.from('nexus-segredo-aes-256-gcm-v1'),
    32
  ));
}

function encrypt(text) {
  const iv = crypto.randomBytes(12);
  const cipher = crypto.createCipheriv('aes-256-gcm', getEncryptionKey(), iv);
  let encrypted = cipher.update(text, 'utf8', 'hex');
  encrypted += cipher.final('hex');
  return ['v2', iv.toString('hex'), cipher.getAuthTag().toString('hex'), encrypted].join(':');
}

function decrypt(encrypted) {
  try {
    const parts = encrypted.split(':');
    if (parts.length !== 4 || parts[0] !== 'v2') return null;
    const [, ivHex, tagHex, encryptedText] = parts;
    const iv = Buffer.from(ivHex, 'hex');
    const decipher = crypto.createDecipheriv('aes-256-gcm', getEncryptionKey(), iv);
    decipher.setAuthTag(Buffer.from(tagHex, 'hex'));
    let decrypted = decipher.update(encryptedText, 'hex', 'utf8');
    decrypted += decipher.final('utf8');
    return decrypted;
  } catch {
    return null;
  }
}

export default {
  name: 'segredo',
  alias: ['secreto', 'secret', 'encriptado'],
  desc: 'Comunicação encriptada entre bot e dono',
  category: 'Nível Deus',
  ownerOnly: true,
  async run({ msg, sock, args }) {
    const subcmd = args[0]?.toLowerCase();
    const text = args.slice(1).join(' ');

    if (subcmd === 'enviar' || subcmd === 'send') {
      if (!text) return msg.reply('Uso: .segredo enviar <mensagem>');
      const encrypted = encrypt(text);
      await msg.reply(
        `🔒 *Mensagem Encriptada*\n\n` +
        encrypted +
        `\n\n_Decifra com: .segredo ler <código>_`
      );
      return;
    }

    if (subcmd === 'ler' || subcmd === 'read') {
      if (!text) return msg.reply('Uso: .segredo ler <código>');
      const decrypted = decrypt(text);
      if (decrypted) {
        await msg.reply(`🔓 *Decifrado:*\n\n${decrypted}`);
      } else {
        await msg.reply('❌ Código inválido ou corrompido.');
      }
      return;
    }

    if (subcmd === 'status') {
      await msg.reply(
        '🔒 *Segredo — Status*\n\n' +
        'Encriptação: AES-256-GCM\n' +
        'Chave: [PROTEGIDA]\n' +
        'Funcionalidade: Comunicação segura bot-dono'
      );
      return;
    }

    await msg.reply(
      '🔒 *Modo Segredo*\n\n' +
      'Encripta mensagens que ninguém consegue ler.\n\n' +
      `*Comandos:*\n` +
      `▸ \`.segredo enviar <msg>\` — Encriptar\n` +
      `▸ \`.segredo ler <código>\` — Decifrar\n` +
      `▸ \`.segredo status\` — Estado`
    );
  },
};
