import settings from '#settings';
import DB from '#db';
export default {
  command: ['cpu', 'processador', 'cpuusage'],
  category: 'niveldeus',
  description: 'Ver uso de CPU do bot',
  ownerOnly: true,
  async run({ msg, sock, args, text }) {
    await msg.reply(`⚙️ A processar: _cpu_\n\n✅ Feito!`);
  },
};
