/**
 * Comando: .idioma — Gestão de Idiomas
 * Nel-Aviso-Bot-Moz 🇲🇿 — Nível Deus Edition
 */
export default {
  name: 'idioma',
  aliases: ['lang', 'language', 'língua'],
  category: 'niveldeus',
  desc: 'Definir ou verificar idioma preferido',
  usage: '.idioma [pt|en|ts|sn|mgh|fr|es]',
  ownerOnly: false,
};

export async function execute(sock, msg, store, args) {
  const chatJid = msg.key.remoteJid;
  const senderJid = msg.key.participant || msg.key.remoteJid;

  if (!args[0]) {
    const lang = global.multilingualEngine?.getUserPreferredLang(senderJid) || 'pt';
    const greeting = global.multilingualEngine?.getGreeting(lang) || '';
    return sock.sendMessage(chatJid, {
      text: `🌐 *Idioma Actual:*\n${global.langNames?.[lang] || lang}\n\n*Idiomas disponíveis:*\n` +
        `pt — Português\n` +
        `en — English\n` +
        `ts — Changana/Tsonga\n` +
        `sn — Sena\n` +
        `mgh — Makhuwa\n` +
        `fr — Français\n` +
        `es — Español\n\n` +
        `Usa: .idioma <código>\nEx: .idioma ts`,
    });
  }

  const validLangs = ['pt', 'en', 'ts', 'sn', 'mgh', 'fr', 'es'];
  const lang = args[0].toLowerCase();

  if (!validLangs.includes(lang)) {
    return sock.sendMessage(chatJid, { text: '❌ Idioma não válido. Opções: pt, en, ts, sn, mgh, fr, es' });
  }

  global.multilingualEngine?.setUserLanguage(senderJid, lang);
  const greeting = global.multilingualEngine?.getGreeting(lang) || '';
  return sock.sendMessage(chatJid, { text: `✅ Idioma definido: ${lang}\n${greeting}` });
}
