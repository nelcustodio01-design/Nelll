// ═══════════════════════════════════════════════════════════════
//  COMMAND — .multibots
//  Nel-Aviso-Bot-Moz 🇲🇿 — Nível Deus SUPREMO
// ═══════════════════════════════════════════════════════════════
import multibots from '../../core/multibots.js';

export default {
    command: ['multibot', 'multibots', 'conectar'],
    category: 'owner',
    description: 'Gere múltiplas instâncias do bot para outras pessoas.',
    ownerOnly: true,
    run: async ({ msg, sock, args, usedPrefix }) => {
        const action = args[0]?.toLowerCase();
        const name = args[1]?.toLowerCase();

        if (!action) {
            return msg.reply(`🌌 **NEXUS MULTIBOTS — GESTÃO DE ELITE**\n\n` +
                `Uso:\n` +
                `• *${usedPrefix}multibot add <nome>* — Criar nova instância (gera QR)\n` +
                `• *${usedPrefix}multibot list* — Listar bots ativos\n` +
                `• *${usedPrefix}multibot stop <nome>* — Desconectar um bot\n\n` +
                `> O sistema Multibot permite escalar a sua tecnologia para outros números.`);
        }

        switch (action) {
            case 'add':
            case 'new':
            case 'conectar':
                if (!name) return msg.reply(`❌ Indique um nome para a instância. Ex: *${usedPrefix}multibot add cliente1*`);
                msg.reply(`⏳ A preparar instância "${name}"... O QR Code será enviado em instantes.`);
                const res = await multibots.startBot(name, msg);
                if (res.status === 'error') msg.reply(`❌ ${res.message}`);
                break;

            case 'list':
            case 'status':
                const active = multibots.listBots();
                if (active.length === 0) return msg.reply('📭 Nenhuma instância secundária ativa no momento.');
                const list = active.map((n, i) => `${i + 1}. 🤖 **${n}** — Online`).join('\n');
                msg.reply(`📊 **INSTÂNCIAS ATIVAS:**\n\n${list}`);
                break;

            case 'stop':
            case 'delete':
                if (!name) return msg.reply(`❌ Indique o nome da instância para parar.`);
                const stopped = multibots.stopBot(name);
                if (stopped) {
                    msg.reply(`✅ Instância "${name}" desconectada e removida.`);
                } else {
                    msg.reply(`❌ Instância "${name}" não encontrada ou já está offline.`);
                }
                break;

            default:
                msg.reply('❌ Acção inválida. Use *add*, *list* ou *stop*.');
        }
    }
};
