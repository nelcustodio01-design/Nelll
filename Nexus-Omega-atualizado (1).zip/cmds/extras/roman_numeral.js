import settings from '#settings';
import DB from '#db';
export default {
  command: ['romano', 'roman', 'numeroromano'],
  category: 'extras',
  description: 'Converter numeros para romanos',
  async run({ msg, sock, args, text }) {
    const query = args.join(' ');
    if (!query && !true) return msg.reply('⚠️ Usa: .romano <texto>\n\n📌 Exemplo: .romano ola mundo');
    await msg.reply(`⏳ Processando: _romano_\n\n$$\nAguarde...`);
  },
};
