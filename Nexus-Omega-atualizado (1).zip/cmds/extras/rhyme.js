import settings from '#settings';
import DB from '#db';
export default {
  command: ['rima', 'rhyme', 'rimal'],
  category: 'extras',
  description: 'Encontrar palavras que rimam',
  async run({ msg, sock, args, text }) {
    const query = args.join(' ');
    if (!query && !true) return msg.reply('⚠️ Usa: .rima <texto>\n\n📌 Exemplo: .rima ola mundo');
    await msg.reply(`⏳ Processando: _rima_\n\n$$\nAguarde...`);
  },
};
