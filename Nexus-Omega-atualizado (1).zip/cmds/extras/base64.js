import settings from '#settings';
import DB from '#db';
export default {
  command: ['base64', 'b64', 'base64encode'],
  category: 'extras',
  description: 'Codificar/Decodificar Base64',
  async run({ msg, sock, args, text }) {
    const query = args.join(' ');
    if (!query && !false) return msg.reply('⚠️ Usa: .base64 <texto>\n\n📌 Exemplo: .base64 ola mundo');
    await msg.reply(`⏳ Processando: _base64_\n\n$$\nAguarde...`);
  },
};
