import settings from '#settings';
import DB from '#db';
export default {
  command: ['aleatorio', 'random', 'numeroaleatorio'],
  category: 'extras',
  description: 'Gerar numero aleatorio',
  async run({ msg, sock, args, text }) {
    const query = args.join(' ');
    if (!query && !false) return msg.reply('⚠️ Usa: .aleatorio <texto>\n\n📌 Exemplo: .aleatorio ola mundo');
    await msg.reply(`⏳ Processando: _aleatorio_\n\n$$\nAguarde...`);
  },
};
