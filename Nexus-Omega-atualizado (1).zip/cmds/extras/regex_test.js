import settings from '#settings';
import DB from '#db';
export default {
  command: ['regex', 'regex101', 'regextest'],
  category: 'extras',
  description: 'Testar expressoes regulares',
  async run({ msg, sock, args, text }) {
    const query = args.join(' ');
    if (!query && !false) return msg.reply('⚠️ Usa: .regex <texto>\n\n📌 Exemplo: .regex ola mundo');
    await msg.reply(`⏳ Processando: _regex_\n\n$$\nAguarde...`);
  },
};
