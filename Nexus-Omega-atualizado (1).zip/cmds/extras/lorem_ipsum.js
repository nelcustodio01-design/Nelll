import settings from '#settings';
import DB from '#db';
export default {
  command: ['lorem', 'loremipsum', 'textofalso'],
  category: 'extras',
  description: 'Gerar texto Lorem Ipsum',
  async run({ msg, sock, args, text }) {
    const query = args.join(' ');
    if (!query && !true) return msg.reply('⚠️ Usa: .lorem <texto>\n\n📌 Exemplo: .lorem ola mundo');
    await msg.reply(`⏳ Processando: _lorem_\n\n$$\nAguarde...`);
  },
};
