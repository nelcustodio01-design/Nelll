import settings from '#settings';
import DB from '#db';
export default {
  command: ['espaco', 'space', 'nasa'],
  category: 'extras',
  description: 'Noticias do espaco e NASA',
  async run({ msg, sock, args, text }) {
    const query = args.join(' ');
    if (!query && !true) return msg.reply('⚠️ Usa: .espaco <texto>\n\n📌 Exemplo: .espaco ola mundo');
    await msg.reply(`⏳ Processando: _espaco_\n\n$$\nAguarde...`);
  },
};
