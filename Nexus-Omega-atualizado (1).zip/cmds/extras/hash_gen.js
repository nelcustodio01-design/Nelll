import settings from '#settings';
import DB from '#db';
export default {
  command: ['hash', 'hashgen', 'sha'],
  category: 'extras',
  description: 'Gerar hash MD5/SHA256',
  async run({ msg, sock, args, text }) {
    const query = args.join(' ');
    if (!query && !false) return msg.reply('⚠️ Usa: .hash <texto>\n\n📌 Exemplo: .hash ola mundo');
    await msg.reply(`⏳ Processando: _hash_\n\n$$\nAguarde...`);
  },
};
