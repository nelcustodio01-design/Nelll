import settings from '#settings';
import DB from '#db';
export default {
  command: ['terramoto', 'earthquake', 'sismo'],
  category: 'extras',
  description: 'Ultimos sismos no mundo',
  async run({ msg, sock, args, text }) {
    const query = args.join(' ');
    if (!query && !true) return msg.reply('⚠️ Usa: .terramoto <texto>\n\n📌 Exemplo: .terramoto ola mundo');
    await msg.reply(`⏳ Processando: _terramoto_\n\n$$\nAguarde...`);
  },
};
