import settings from '#settings';
import DB from '#db';
export default {
  command: ['npm', 'npms', 'npmsearch'],
  category: 'extras',
  description: 'Pesquisar pacotes no NPM',
  async run({ msg, sock, args, text }) {
    const query = args.join(' ');
    if (!query && !true) return msg.reply('⚠️ Usa: .npm <texto>\n\n📌 Exemplo: .npm ola mundo');
    await msg.reply(`⏳ Processando: _npm_\n\n$$\nAguarde...`);
  },
};
