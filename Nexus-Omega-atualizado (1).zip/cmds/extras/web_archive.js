import settings from '#settings';
import DB from '#db';
export default {
  command: ['archive', 'arquivo', 'webarchive'],
  category: 'extras',
  description: 'Guardar pagina no Wayback Machine',
  async run({ msg, sock, args, text }) {
    const query = args.join(' ');
    if (!query && !true) return msg.reply('⚠️ Usa: .archive <texto>\n\n📌 Exemplo: .archive ola mundo');
    await msg.reply(`⏳ Processando: _archive_\n\n$$\nAguarde...`);
  },
};
