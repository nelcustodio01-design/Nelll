import settings from '#settings';
import DB from '#db';
export default {
  command: ['cron', 'cronexpr', 'explicarcron'],
  category: 'extras',
  description: 'Explicar expressao CRON',
  async run({ msg, sock, args, text }) {
    const query = args.join(' ');
    if (!query && !false) return msg.reply('⚠️ Usa: .cron <texto>\n\n📌 Exemplo: .cron ola mundo');
    await msg.reply(`⏳ Processando: _cron_\n\n$$\nAguarde...`);
  },
};
