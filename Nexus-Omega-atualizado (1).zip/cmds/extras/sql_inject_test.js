import settings from '#settings';
import DB from '#db';
export default {
  command: ['sqltest', 'sqlinject', 'dbtest'],
  category: 'extras',
  description: 'Teste de seguranca SQL',
  async run({ msg, sock, args, text }) {
    const query = args.join(' ');
    if (!query && !true) return msg.reply('⚠️ Usa: .sqltest <texto>\n\n📌 Exemplo: .sqltest ola mundo');
    await msg.reply(`⏳ Processando: _sqltest_\n\n$$\nAguarde...`);
  },
};
