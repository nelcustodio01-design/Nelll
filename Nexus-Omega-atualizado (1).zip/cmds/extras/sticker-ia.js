import fetch from 'node-fetch';
import DB from '#db';
export default {
  command: ['stickerurl','surl','stickerweb'],
  category: 'extras',
  description: 'Criar sticker a partir de URL de imagem. 🖼️',
  run: async ({ msg, sock, args, usedPrefix, command }) => {
    const url = args[0];
    if (!url || !/^https?:\/\//.test(url)) {
      return msg.reply(`🖼️ *STICKER DE URL*\n\n✎ *Uso:*\n▸ *${usedPrefix+command} https://link-da-imagem.jpg*`);
    }
    await msg.react('🕒');
    try {
      const user  = DB.getUser(msg.sender);
      const pack  = user?.metadatos  || 'Nel-Aviso-Bot-Moz';
      const autor = user?.metadatos2 || 'Nel Custódio';
      const res   = await fetch(url, { headers: { 'User-Agent': 'Mozilla/5.0' } });
      if (!res.ok) throw new Error('URL inacessível');
      const buf = Buffer.from(await res.arrayBuffer());
      const { writeExif } = (await import('../../core/exif.js')).default;
      const webp = await writeExif(
        { mimetype: res.headers.get('content-type') || 'image/jpeg', data: buf },
        { packname: pack, author: autor }
      );
      await sock.sendMessage(msg.chat, { sticker: webp }, { quoted: msg });
      await msg.react('✅');
    } catch (e) {
      await msg.react('❌');
      return msg.reply(`❧ Erro: ${e.message}`);
    }
  },
};
