import settings from '#settings';
import DB from '#db';
export default {
  command: ['imposto', 'tax', 'irs'],
  category: 'ferramentas',
  description: 'Calculadora de impostos',
  async run({ msg, args, usedPrefix, command }) {
    const amount = Number(args[0]); const rate = Number(args[1]);
    if (!(amount >= 0 && rate >= 0)) return msg.reply(`🧾 Uso: ${usedPrefix}${command} valor taxa_percentual`);
    const tax = amount * rate / 100;
    return msg.reply(`🧾 Imposto estimado: *${tax.toFixed(2)} MT*\nLíquido: *${(amount - tax).toFixed(2)} MT*`);
  },
};
