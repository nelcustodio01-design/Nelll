import settings from '#settings';
import DB from '#db';
export default {
  command: ['gorjeta', 'tip'],
  category: 'ferramentas',
  description: 'Calcular gorjeta',
  async run({ msg, args, usedPrefix, command }) {
    const amount = Number(args[0]); const rate = Number(args[1] || 10);
    if (!(amount >= 0 && rate >= 0)) return msg.reply(`🍽️ Uso: ${usedPrefix}${command} valor [percentagem]`);
    const tip = amount * rate / 100;
    return msg.reply(`🍽️ Gorjeta: *${tip.toFixed(2)} MT*\n💰 Total: *${(amount + tip).toFixed(2)} MT*`);
  },
};
