import settings from '#settings';
import DB from '#db';
export default {
  command: ['desconto', 'discount', 'descontar'],
  category: 'ferramentas',
  description: 'Calcular desconto',
  async run({ msg, args, usedPrefix, command }) {
    const amount = Number(args[0]); const rate = Number(args[1]);
    if (!(amount >= 0 && rate >= 0)) return msg.reply(`💸 Uso: ${usedPrefix}${command} valor percentagem`);
    const saving = amount * rate / 100;
    return msg.reply(`💸 Desconto: *${saving.toFixed(2)} MT*\n💰 Total: *${(amount - saving).toFixed(2)} MT*`);
  },
};
