import settings from '#settings';
import DB from '#db';
export default {
  command: ['contrato', 'contract', 'acordo'],
  category: 'ferramentas',
  description: 'Modelo de contrato',
  async run({ msg, args }) {
    const subject = args.join(' ') || 'prestação de serviços';
    return msg.reply(`📄 *MODELO DE ACORDO*\n\nPartes: ____________________\nObjecto: ${subject}\nValor e prazo: ____________________\nObrigações: ____________________\nAssinaturas: ____________________\n\nModelo inicial. Revisa com um profissional jurídico antes de assinar.`);
  },
};
