import settings from '#settings';
import DB from '#db';
export default {
  command: ['lei', 'law', 'juridico'],
  category: 'ferramentas',
  description: 'Informacoes juridicas basicas',
  async run({ msg, args }) {
    return msg.reply(`⚖️ Informação jurídica geral sobre *${args.join(' ') || 'o teu tema'}*. A lei depende do caso e da jurisdição; para uma decisão concreta consulta um advogado ou entidade oficial.`);
  },
};
