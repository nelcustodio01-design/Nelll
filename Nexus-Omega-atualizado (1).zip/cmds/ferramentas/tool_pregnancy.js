import settings from '#settings';
import DB from '#db';
export default {
  command: ['gravidez', 'pregnancy', 'gestacao'],
  category: 'ferramentas',
  description: 'Calcular semanas de gravidez',
  async run({ msg, args, usedPrefix, command }) {
    const lastPeriod = new Date(args[0]);
    if (Number.isNaN(lastPeriod.getTime())) return msg.reply(`🤰 Uso: ${usedPrefix}${command} AAAA-MM-DD (data da última menstruação)`);
    const days = Math.max(0, Math.floor((Date.now() - lastPeriod.getTime()) / 86400000));
    const due = new Date(lastPeriod.getTime() + 280 * 86400000);
    return msg.reply(`🤰 Idade gestacional aproximada: *${Math.floor(days / 7)} semanas*\n📅 Data provável: *${due.toLocaleDateString('pt-PT')}*\n\nConsulte um profissional de saúde para confirmação.`);
  },
};
