export default {
  command: ['perguntas', 'testar'],
  category: 'educacao',
  description: 'Quiz educativo com perguntas reais',
  async run({ msg, args, usedPrefix, command }) {
    const categorias = ['ciencia', 'historia', 'geografia', 'matematica', 'geral'];
    const categoria = args[0] && args[0].toLowerCase() || 'geral';
    
    const perguntas = {
      ciencia: [
        { q: 'Qual é o elemento químico mais abundante no universo?', r: 'Hidrogênio' },
        { q: 'Qual é a velocidade da luz?', r: '300.000 km/s' },
        { q: 'Quantos planetas tem o sistema solar?', r: '8' },
        { q: 'Qual é a fórmula da água?', r: 'H2O' },
        { q: 'Qual é o maior órgão do corpo humano?', r: 'Pele' },
      ],
      historia: [
        { q: 'Em que ano Moçambique se tornou independente?', r: '1975' },
        { q: 'Quem foi o primeiro presidente de Moçambique?', r: 'Samora Machel' },
        { q: 'Em que ano começou a Segunda Guerra Mundial?', r: '1939' },
        { q: 'Quem descobriu o Brasil?', r: 'Pedro Álvares Cabral' },
        { q: 'Em que ano o homem chegou à Lua?', r: '1969' },
      ],
      geografia: [
        { q: 'Qual é a capital de Moçambique?', r: 'Maputo' },
        { q: 'Qual é o maior rio de Moçambique?', r: 'Zambeze' },
        { q: 'Qual é o maior país do mundo?', r: 'Rússia' },
        { q: 'Qual é o continente mais populoso?', r: 'Ásia' },
        { q: 'Qual é o oceano mais profundo?', r: 'Pacífico' },
      ],
      matematica: [
        { q: 'Quanto é 15 × 12?', r: '180' },
        { q: 'Qual é a raiz quadrada de 144?', r: '12' },
        { q: 'Quanto é 7³?', r: '343' },
        { q: 'Quantos lados tem um hexágono?', r: '6' },
        { q: 'Qual é o valor de Pi (2 casas)?', r: '3.14' },
      ],
      geral: [
        { q: 'Qual é a língua oficial de Moçambique?', r: 'Português' },
        { q: 'Quantas províncias tem Moçambique?', r: '11' },
        { q: 'Qual é a moeda de Moçambique?', r: 'Metical' },
        { q: 'Qual é o animal nacional de Moçambique?', r: 'Leopardo' },
        { q: 'Em que continente fica Moçambique?', r: 'África' },
      ]
    };

    const banco = perguntas[categoria] || perguntas.geral;
    const pergunta = banco[Math.floor(Math.random() * banco.length)];
    
    return msg.reply(
      '🧠 *QUIZ - ' + categoria.toUpperCase() + '*\n\n' +
      '📝 Pergunta: *' + pergunta.q + '*\n\n' +
      '_Responda com: *' + usedPrefix + command + ' responder <resposta>*_'
    );
  }
};
