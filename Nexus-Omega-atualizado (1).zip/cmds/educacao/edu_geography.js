import settings from '#settings';
import DB from '#db';

export default {
  command: ['geografia', 'geography', 'paises'],
  category: 'educacao',
  description: 'Aprender geografia',
  async run({ msg, args, usedPrefix, command, text }) {
    const dados = {
      'maputo': 'Capital de Moçambique, localizada na baía de Maputo. População: ~1.1M',
      'beira': 'Segunda maior cidade, porto importante no Canal de Moçambique.',
      'nampula': 'Capital da província mais populosa do norte de Moçambique.',
      'pemba': 'Capital de Cabo Delgado, porta de entrada para as ilhas Quirimbas.',
      'quelimane': 'Cidade costeira, uma das mais antigas de Moçambique.',
      'chimoio': 'Capital de Manica, centro agrícola e comercial.',
      'tete': 'Capital de Tete, conhecida pelas minas de carvão.',
      'lichinga': 'Capital de Niassa, cidade mais alta de Moçambique.',
    };
    const cidade = args[0]?.toLowerCase();
    if (!cidade) {
      const lista = Object.keys(dados).map(c => `• *${c.charAt(0).toUpperCase()+c.slice(1)}*`).join('\n');
      return msg.reply(`🌍 *GEOGRAFIA DE MOÇAMBIQUE*\n\nUso: *${usedPrefix}${command} <cidade>*\n\nCidades: ${lista}`);
    }
    const info = dados[cidade];
    if (!info) return msg.reply(`❌ Cidade não encontrada.`);
    return msg.reply(`🌍 *${cidade.toUpperCase()}*\n\n${info}`);
  }
};
