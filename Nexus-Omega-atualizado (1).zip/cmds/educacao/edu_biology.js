import settings from '#settings';
import DB from '#db';
export default {
  command: ['biologia', 'biology', 'celulas'],
  category: 'educacao',
  description: 'Curiosidades de biologia',
  async run({ msg, args }) {
    const topic = args.join(' ').toLowerCase();
    const facts = topic.includes('célula') || topic.includes('celula')
      ? 'A célula é a unidade básica da vida; células vegetais possuem parede celular e cloroplastos.'
      : 'O ADN guarda informação genética e as proteínas executam muitas funções essenciais nas células.';
    return msg.reply(`🧬 ${facts}`);
  },
};
