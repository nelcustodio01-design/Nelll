import settings from '#settings';
import DB from '#db';

export default {
  command: ['ciencia', 'science', 'fisica'],
  category: 'educacao',
  description: 'Curiosidades cientificas',
  async run({ msg, args, usedPrefix, command, text }) {
    const curiosidades = [
      'O Sol perde 4 milhões de toneladas de massa a cada segundo.',
      'Um raio é 5x mais quente que a superfície do Sol.',
      'O cérebro humano gera mais conexões que o número de estrelas na Via Láctea.',
      'A água pode ferver e congelar ao mesmo tempo (ponto triplo).',
      'O ADN de todas as células humanas estendidas chegaria a Plutão e voltaria 17x.',
      'Uma colher de sopa de estrela de neutrões pesa 1 bilhão de toneladas.',
      'O universo tem 13.8 bilhões de anos.',
      'Existem mais árvores na Terra do que estrelas na Via Láctea.',
    ];
    const curiosidade = curiosidades[Math.floor(Math.random() * curiosidades.length)];
    return msg.reply(`🔬 *CURIOSIDADE CIENTÍFICA*\n\n${curiosidade}\n\n_Use novamente para outra curiosidade._`);
  }
};
