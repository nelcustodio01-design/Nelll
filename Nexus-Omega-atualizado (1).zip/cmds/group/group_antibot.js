import settings from '#settings';
import DB from '#db';
export default {
  command: ['antibot', 'antibots', 'blockbot'],
  category: 'group',
  description: 'Expulsar bots automaticamente',
  groupOnly: true,
  async run({ msg, sock, args, text, isOwner, isAdmin, chatId, sender }) {
    if (!isOwner && !isAdmin) return msg.reply('⚠️ So admins podem usar este comando.');
    const query = args.join(' ');
    await msg.reply(`⚙️ A processar: _antibot_\n$\n\n✅ Configuracao actualizada com sucesso!`);
  },
};
