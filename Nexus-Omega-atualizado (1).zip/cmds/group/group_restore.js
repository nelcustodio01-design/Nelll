import settings from '#settings';
import DB from '#db';
export default {
  command: ['restore', 'restaurar', 'restaurargrupo'],
  category: 'group',
  description: 'Restaurar backup do grupo',
  groupOnly: true,
  async run({ msg, sock, args, text, isOwner, isAdmin, chatId, sender }) {
    if (!isOwner && !isAdmin) return msg.reply('⚠️ So admins podem usar este comando.');
    const query = args.join(' ');
    await msg.reply(`⚙️ A processar: _restore_\n$\n\n✅ Configuracao actualizada com sucesso!`);
  },
};
