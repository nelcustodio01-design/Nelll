import settings from '#settings';
import DB from '#db';
export default {
  command: ['packdl', 'downloadpack', 'baixarpack'],
  category: 'stickers',
  description: 'Baixar pack de stickers',
  async run({ msg, sock, args, text }) {
    const query = args.join(' ');
    if (!query && !false) return msg.reply('⚠️ Usa: .packdl <texto/URL>\n\n📌 Exemplo: .packdl ola mundo');
    await msg.reply(`⏳ A criar sticker...\n\n🎨 Efeito: _packdl_\n$\nAguarde...`);
  },
};
