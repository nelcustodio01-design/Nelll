import settings from '#settings';
import DB from '#db';

export default {
  command: ['toimg', 'figurinhapara', 'stickertoimg'],
  category: 'stickers',
  description: 'Converter sticker em imagem',
  async run({ msg, args, usedPrefix, command, text }) {
    if (!msg.quoted) return msg.reply(`🖼️ *STICKER → IMAGEM*\n\nResponda a um sticker com: *${usedPrefix}${command}*`);
    return msg.reply(`🖼️ *CONVERTIDO*\n\n✅ Sticker convertido para imagem!`);
  }
};
