import settings from '#settings';
import DB from '#db';
export default {
  command: ['deepfry', 'fry', 'frysticker'],
  category: 'stickers',
  description: 'Efeito deepfry no sticker',
  async run({ msg, sock, args, text }) {
    const query = args.join(' ');
    if (!query && !false) return msg.reply('⚠️ Usa: .deepfry <texto/URL>\n\n📌 Exemplo: .deepfry ola mundo');
    await msg.reply(`⏳ A criar sticker...\n\n🎨 Efeito: _deepfry_\n$\nAguarde...`);
  },
};
