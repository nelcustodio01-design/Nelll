import settings from '#settings';
import DB from '#db';
export default {
  command: ['wasted', 'wastedsticker', 'gta'],
  category: 'stickers',
  description: 'Efeito GTA Wasted no sticker',
  async run({ msg, sock, args, text }) {
    const query = args.join(' ');
    if (!query && !false) return msg.reply('⚠️ Usa: .wasted <texto/URL>\n\n📌 Exemplo: .wasted ola mundo');
    await msg.reply(`⏳ A criar sticker...\n\n🎨 Efeito: _wasted_\n$\nAguarde...`);
  },
};
