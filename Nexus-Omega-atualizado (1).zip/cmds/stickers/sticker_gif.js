import settings from '#settings';
import DB from '#db';
export default {
  command: ['gifsticker', 'stickeranimado', 'animatedsticker'],
  category: 'stickers',
  description: 'Criar sticker animado de GIF',
  async run({ msg, sock, args, text }) {
    const query = args.join(' ');
    if (!query && !false) return msg.reply('⚠️ Usa: .gifsticker <texto/URL>\n\n📌 Exemplo: .gifsticker ola mundo');
    await msg.reply(`⏳ A criar sticker...\n\n🎨 Efeito: _gifsticker_\n$\nAguarde...`);
  },
};
