import settings from '#settings';
import DB from '#db';

export default {
  command: ['memesticker', 'stickermeme', 'memes'],
  category: 'stickers',
  description: 'Criar sticker de meme',
  async run({ msg, args, usedPrefix, command, text }) {
    if (!msg.quoted) return msg.reply(`😂 *MEME STICKER*\n\nResponda a uma foto com: *${usedPrefix}${command} <texto superior>|<texto inferior>*`);
    return msg.reply(`😂 *MEME STICKER*\n\n✅ Sticker de meme criado!`);
  }
};
