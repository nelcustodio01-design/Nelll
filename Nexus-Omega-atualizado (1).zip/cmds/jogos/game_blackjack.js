import settings from '#settings';
import DB from '#db';

export default {
  command: ['blackjack', '21', 'cartas'],
  category: 'jogos',
  description: 'Jogo de blackjack',
  async run({ msg, args, usedPrefix, command, text }) {
    const cartas = ['A', '2', '3', '4', '5', '6', '7', '8', '9', '10', 'J', 'Q', 'K'];
    const valores = { 'A': 11, '2': 2, '3': 3, '4': 4, '5': 5, '6': 6, '7': 7, '8': 8, '9': 9, '10': 10, 'J': 10, 'Q': 10, 'K': 10 };
    const tirar = () => cartas[Math.floor(Math.random() * cartas.length)];
    const jogador = [tirar(), tirar()];
    const dealer = [tirar(), tirar()];
    const somaJ = valores[jogador[0]] + valores[jogador[1]];
    const somaD = valores[dealer[0]] + valores[dealer[1]];
    let resultado;
    if (somaJ > 21) resultado = '💀 *ESTOURASTE!* Dealer ganha.';
    else if (somaJ > somaD) resultado = '🎉 *GANHASTE!* Parabéns!';
    else resultado = '😔 *Dealer ganha.* Tenta de novo!';
    return msg.reply(`🃏 *BLACKJACK*\n\n👤 Tu: ${jogador[0]} + ${jogador[1]} = *${somaJ}*\n🤖 Dealer: ${dealer[0]} + ?\n\n${resultado}`);
  }
};
