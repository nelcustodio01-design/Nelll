import settings from '#settings';
import DB from '#db';
export default {
  command: ['banda', 'bandquiz', 'musicquiz'],
  category: 'jogos',
  description: 'Adivinhar banda/musica',
  async run({ msg, sock, args, text, sender }) {
    await msg.reply(`🎮 A iniciar: _banda_\n\n⏳ Aguarde...`);
  },
};
