import settings from '#settings';
import DB from '#db';

export default {
  command: ['matquiz', 'calculomental', 'contamente'],
  category: 'jogos',
  description: 'Jogo de calculo mental',
  async run({ msg, args, usedPrefix, command, text }) {
    const a = Math.floor(Math.random() * 100) + 1;
    const b = Math.floor(Math.random() * 100) + 1;
    const ops = ['+', '-', '×'];
    const op = ops[Math.floor(Math.random() * 3)];
    let resposta;
    if (op === '+') resposta = a + b;
    else if (op === '-') resposta = a - b;
    else resposta = a * b;
    return msg.reply(`🧮 *CALCULO MENTAL*\n\n📝 Quanto é *${a} ${op} ${b}*?\n\n_Responda: ${usedPrefix}calculomental ${resposta}_`);
  }
};
