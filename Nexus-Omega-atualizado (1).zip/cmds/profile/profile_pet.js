import settings from '#settings';
import DB from '#db';

export default {
  command: ['pet', 'animal', 'bichinho'],
  category: 'profile',
  description: 'Pet virtual',
  async run({ msg, args, usedPrefix, command, text }) {
    const pets = ['🐱 Gato', '🐶 Cão', '🐰 Coelho', '🦊 Raposa', '🐼 Panda', '🦁 Leão', '🐬 Golfinho', '🦅 Águia'];
    const pet = pets[Math.floor(Math.random() * pets.length)];
    const felicidade = Math.floor(Math.random() * 100);
    const fome = Math.floor(Math.random() * 100);
    return msg.reply(`🐾 *PET VIRTUAL*\n\n${pet}\n\n😊 Felicidade: *${felicidade}%*\n🍖 Fome: *${fome}%*\n\n💡 Use *${usedPrefix}pet alimentar* ou *${usedPrefix}pet brincar*`);
  }
};
