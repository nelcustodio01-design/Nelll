import settings from '#settings';
import DB from '#db';

export default {
  command: ['conquistas', 'achievements', 'badges'],
  category: 'profile',
  description: 'Ver conquistas',
  async run({ msg, args, usedPrefix, command, text }) {
    const conquistas = [
      { nome: '🌟 Primeiro Comando', desc: 'Usou o primeiro comando' },
      { nome: '💬 Social', desc: 'Enviou 100 mensagens' },
      { nome: '🎯 Preciso', desc: 'Acertou 10 trivia' },
      { nome: '💰 Rico', desc: 'Acumulou 10.000 moedas' },
      { nome: '🏆 Campeão', desc: 'Ganhou 50 jogos' },
      { nome: '📚 Estudante', desc: 'Usou 50 comandos de educação' },
    ];
    const desbloqueadas = Math.floor(Math.random() * conquistas.length) + 1;
    const lista = conquistas.map((c, i) => `${i < desbloqueadas ? '✅' : '🔒'} ${c.nome} - ${c.desc}`).join('\n');
    return msg.reply(`🏆 *CONQUISTAS*\n\n${lista}\n\n📊 Desbloqueadas: *${desbloqueadas}/${conquistas.length}*`);
  }
};
