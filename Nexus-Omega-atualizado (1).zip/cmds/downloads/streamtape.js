import settings from '#settings';
import DB from '#db';
export default {
  command: ['streamtape', 'stdl', 'st'],
  category: 'downloads',
  description: 'Baixar videos do Streamtape',
  async run({ msg, sock, args, text }) {
    const query = args.join(' ');
    if (!query) return msg.reply('⚠️ Usa: .streamtape <link ou nome>\n\n📌 Exemplo: .streamtape https://exemplo.com/video');
    await msg.reply(`🔄 A buscar em Streamtape...\n\n🔍 Query: _${query}_\n⏳ Aguarde...`);
    // API externa para streamtape
    try {
      // Implementacao real: chamar API de streamtape
      await msg.reply(`⏳ Processando: _${query}_\n\n💡 Para usar este comando, configure a API correspondente no .env`);
    } catch (e) {
      await msg.reply(`❌ Erro: ${e.message}`);
    }
  },
};
