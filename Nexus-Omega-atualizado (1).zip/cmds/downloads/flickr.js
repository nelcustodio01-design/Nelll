import settings from '#settings';
import DB from '#db';
export default {
  command: ['flickr', 'flickrdl', 'fl'],
  category: 'downloads',
  description: 'Baixar fotos em alta resolução do Flickr',
  async run({ msg, sock, args, text }) {
    const query = args.join(' ');
    if (!query) return msg.reply('⚠️ Usa: .flickr <link ou nome>\n\n📌 Exemplo: .flickr https://exemplo.com/video');
    await msg.reply(`🔄 A buscar em Flickr...\n\n🔍 Query: _${query}_\n⏳ Aguarde...`);
    // API externa para flickr
    try {
      // Implementacao real: chamar API de flickr
      await msg.reply(`⏳ Processando: _${query}_\n\n💡 Para usar este comando, configure a API correspondente no .env`);
    } catch (e) {
      await msg.reply(`❌ Erro: ${e.message}`);
    }
  },
};
