import settings from '#settings';
import DB from '#db';
export default {
  command: ['vk', 'vkdl', 'vkontakte'],
  category: 'redes',
  description: 'Baixar do VKontakte',
  async run({ msg, sock, args, text }) {
    const query = args.join(' ');
    if (!query) return msg.reply('⚠️ Usa: .vk <link>\n\n📌 Exemplo: .vk https://...');
    await msg.reply(`🔄 A baixar de Vk...\n\n🔗 Link: _${query}_\n⏳ Aguarde...`);
  },
};
