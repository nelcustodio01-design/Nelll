import axios from 'axios'
import db from '#db';

export default {
  command: ['gelbooru', 'gbooru'],
  category: 'nsfw',
  description: 'Pesquisar imagems en Gelbooru.',
  run: async ({ msg, sock, args, usedPrefix, command }) => {
    try {
      const chat = db.getChat(msg.chat);
      if (!chat.nsfw) return msg.reply(`ꕥ O conteúdo *NSFW* está desativado neste grupo.\n\nUn *administrador* pode ativá-lo com o comando:\n» *${usedPrefix}nsfw on*`)
      if (!args[0]) return sock.reply(msg.chat, `《✧》 Deve especificar tags para buscar\n> Exemplo » *${usedPrefix + command} neko*`, msg)
      await msg.react('🕒')
      const tag = args.join(' ').replace(/\s+/g, '_')
      const endpoint = new URL('https://gelbooru.com/index.php')
      Object.entries({ page: 'dapi', s: 'post', q: 'index', json: '1', limit: '20', tags: tag }).forEach(([key, value]) => endpoint.searchParams.set(key, value))
      if (process.env.GELBOORU_API_KEY && process.env.GELBOORU_USER_ID) {
        endpoint.searchParams.set('api_key', process.env.GELBOORU_API_KEY)
        endpoint.searchParams.set('user_id', process.env.GELBOORU_USER_ID)
      }
      const url = endpoint.toString()
      const res = await axios.get(url, { headers: { 'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36', 'Referer': 'https://gelbooru.com/', 'Accept': 'application/json' } })
      const data = res.data?.post || []
      if (!data.length) return sock.reply(msg.chat, `《✧》 Nenhum resultado encontrado para ${tag}`, msg)
      const shuffled = data.sort(() => Math.random() - 0.5)
      let sent = false
      for (const post of shuffled) {
        const fileUrl = post.file_url || post.sample_url
        if (!fileUrl || !/\.(jpe?g|png|gif|mp4)(\?.*)?$/i.test(fileUrl)) continue
        try {
          const imgRes = await axios.get(fileUrl, { responseType: 'arraybuffer', headers: { 'Referer': 'https://gelbooru.com/', 'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36' }, timeout: 15000 })
          const buffer = Buffer.from(imgRes.data)
          const isVideo = /\.mp4(\?.*)?$/i.test(fileUrl)
          const caption = `ꕥ Resultados para » ${tag}`
          if (isVideo) {
            await sock.sendMessage(msg.chat, { video: buffer, caption, mentions: [msg.sender] })
          } else {
            await sock.sendMessage(msg.chat, { image: buffer, caption, mentions: [msg.sender] })
          }
          sent = true
          break
        } catch {}
      }
      if (!sent) return sock.reply(msg.chat, `《✧》 Nenhum resultado encontrado para ${tag}`, msg)
      await msg.react('✔️')
    } catch (e) {
      await msg.react('✖️')
      await msg.reply(`> Ocorreu um erro inesperado ao executar o comando *${usedPrefix + command}*. Por favor tente novamente ou contacte o suporte se o problema persistir.\n> [Erro: *${e.message}*]`)
    }
  }
}
