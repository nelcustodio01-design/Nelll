import fetch from 'node-fetch';
import db from '#db';

export default {
  command: ['r34', 'rule34', 'rule'],
  category: 'nsfw',
  description: 'Pesquisar imagems en Rule34.',
  run: async ({ msg, sock, args, usedPrefix, command }) => {
    try {
      const chat = db.getChat(msg.chat);
      if (!chat.nsfw) return msg.reply(`ꕥ O conteúdo *NSFW* está desativado neste grupo.\n\nUn *administrador* pode ativá-lo com o comando:\n» *${usedPrefix}nsfw on*`);
      if (!args[0]) return sock.reply(msg.chat, `《✧》 Deve especificar tags para buscar\n> Exemplo » *${usedPrefix + command} neko*`, msg);
      await msg.react('🕒');
      const tag = args[0].replace(/\s+/g, '_');
      let mediaList = [];
      const endpoint = new URL('https://api.rule34.xxx/index.php');
      Object.entries({ page: 'dapi', s: 'post', q: 'index', json: '1', tags: tag }).forEach(([key, value]) => endpoint.searchParams.set(key, value));
      if (process.env.RULE34_API_KEY && process.env.RULE34_USER_ID) {
        endpoint.searchParams.set('api_key', process.env.RULE34_API_KEY);
        endpoint.searchParams.set('user_id', process.env.RULE34_USER_ID);
      }
      const url = endpoint.toString();
      const res = await fetch(url, { headers: { 'User-Agent': 'Mozilla/5.0', 'Accept': 'application/json' } });
      const type = res.headers.get('content-type') || '';
      if (res.ok && type.includes('json')) {
        const json = await res.json();
        const data = Array.isArray(json) ? json : json?.post || json?.data || [];
        const valid = data.map(i => i?.file_url || i?.sample_url || i?.preview_url).filter(u => typeof u === 'string' && /\.(jpe?g|png|gif|mp4)$/i.test(u));
        if (valid.length) {
          mediaList = [...new Set(valid)].sort(() => Math.random() - 0.5);
        }
      }
      if (!mediaList.length)
        return sock.reply(msg.chat, `《✧》 Nenhum resultado encontrado para ${tag}`, msg);
      const media = mediaList[0];
      const caption = `ꕥ Resultados para » ${tag}`;
      if (media.endsWith('.mp4')) {
        await sock.sendMessage(msg.chat, { video: { url: media }, caption, mentions: [msg.sender] });
      } else {
        await sock.sendMessage(msg.chat, { image: { url: media }, caption, mentions: [msg.sender] });
      }
      await msg.react('✔️');
    } catch (e) {
      await msg.react('✖️');
      await msg.reply(`> Ocorreu um erro inesperado ao executar o comando *${usedPrefix + command}*. Por favor tente novamente ou contacte o suporte se o problema persistir.\n> [Erro: *${e.message}*]`);
    }
  }
};