/**
 * Comprar VIP removido por solicitação do utilizador.
 * Este ficheiro está desativado.
 */
export default {
  command: ['comprar_vip_disabled'],
  category: 'main',
  description: 'Desativado',
  run: async ({ msg }) => {}
};
