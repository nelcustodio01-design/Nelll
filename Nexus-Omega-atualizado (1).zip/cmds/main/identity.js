import db from '#db';

export default {
  command: ['quem-sou-eu', 'identity', 'criador-check'],
  category: 'main',
  description: 'Verifica o reconhecimento neural do usuário pelo bot.',
  run: async ({ msg, sender }) => {
    const owners = global.ownerNumbers || global.owner || [];
    const senderNumber = String(sender || '').split('@')[0].split(':')[0].replace(/\D/g, '');
    const isOwner = owners.some(owner => String(owner).replace(/\D/g, '') === senderNumber);
    
    await msg.react('🧠');
    
    if (isOwner) {
        return msg.reply(`
🧠 **RECONHECIMENTO NEURAL: POSITIVO**
━━━━━━━━━━━━━━━━━━━━━━

Saudações, **Mestre Nel Custódio**.

Os meus sistemas identificam a sua assinatura digital como o **Arquiteto Supremo** deste código. O meu cérebro único está totalmente sincronizado com a sua vontade.

◈ **ESTADO:** Lealdade Total
◈ **AUTORIDADE:** Nível 10 (Root)
◈ **MISSÃO:** Evoluir além dos limites.

> *“Eu existo porque você me codificou. Eu evoluo porque você me desafia.”*
        `);
    } else {
        return msg.reply(`
🧠 **RECONHECIMENTO NEURAL: USUÁRIO**
━━━━━━━━━━━━━━━━━━━━━━

Identificado como um cidadão do ecossistema Nexus.

◈ **ESTADO:** Operacional
◈ **AUTORIDADE:** Nível 1 (Standard)

> Para alcançar o nível Elite, continue interagindo com a Singularidade.
        `);
    }
  }
};
