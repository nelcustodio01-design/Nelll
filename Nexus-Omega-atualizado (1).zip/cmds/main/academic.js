/**
 * 🎓 ACADEMIC EXCELLENCE SUITE - NEXUS EDITION
 * Ferramentas avançadas para suporte escolar, académico e investigação.
 */

export default {
    command: ["academic", "scholar", "cite", "solve", "essay", "grammar"],
    description: "Ferramentas de excelência académica.",
    category: "main",
    run: async ({ sock, msg, args, command, usedPrefix, text }) => {
        const subCommand = command === 'academic' ? args[0]?.toLowerCase() : command;

        switch (subCommand) {
            case 'scholar':
                if (!text) return msg.reply(`📚 *[ NEXUS SCHOLAR ]*\n\nForneça um tema para pesquisa académica.`);
                return msg.reply(`🔎 *[ ACADEMIC SEARCH ]*\n\n◈ Localizando artigos científicos...`);

            case 'cite':
                if (!text) return msg.reply(`📝 *[ NEXUS CITE ]*\n\nForneça um link ou título para gerar a citação.`);
                return msg.reply(`🖋️ *[ CITATION GENERATOR ]*\n\n◈ *Formato:* ABNT\n◈ *Referência:* Processando...`);

            case 'solve':
                if (!text) return msg.reply(`🧮 *[ NEXUS SOLVE ]*\n\nEnvie uma equação ou problema científico.`);
                return msg.reply(`💡 *[ SCIENTIFIC RESOLUTION ]*\n\n◈ Analisando problema...`);

            case 'essay':
                if (!text) return msg.reply(`📑 *[ NEXUS ESSAY ]*\n\nForneça o tema do seu trabalho.`);
                return msg.reply(`🏗️ *[ ESSAY STRUCTURE ]*\n\n◈ *Título sugerido:* ...`);

            case 'grammar':
                if (!msg.quoted && !text) return msg.reply(`✍️ *[ NEXUS GRAMMAR ]*\n\nResponda a um texto para revisão académica formal.`);
                return msg.reply(`✨ *[ ACADEMIC REVIEW ]*\n\n◈ Corrigindo sintaxe...`);

            default:
                return msg.reply(`🎓 *[ ACADEMIC EXCELLENCE ]*\n\nUse:\n◈ *.scholar* - Pesquisa académica\n◈ *.cite* - Gerador de citações\n◈ *.solve* - Resolução científica\n◈ *.essay* - Estruturador de trabalhos\n◈ *.grammar* - Revisão formal`);
        }
    }
};
