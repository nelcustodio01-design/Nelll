/**
 * ╔══════════════════════════════════════════════════════════════╗
 *   NEL-AVISO-BOT-MOZ · cmds/main/menu.js
 *   V20 NEXUS OMEGA - MENU UNIFICADO DE ELITE
 *   Orgulho da Zambézia para Boane 🇲🇿
 * ╚══════════════════════════════════════════════════════════════╝
 */
import db from '#db';
import moment from 'moment-timezone';
import os from 'os';
import { getRandomOmegaImage } from '../../core/gallery.js';

function formatUptime(ms) {
  const s = Math.floor(ms / 1000);
  const m = Math.floor(s / 60);
  const h = Math.floor(m / 60);
  const d = Math.floor(h / 24);
  return [d && `${d}d`, `${h % 24}h`, `${m % 60}m`, `${s % 60}s`].filter(Boolean).join(' ');
}

const CATEGORY_ICONS = {
  ia: '🧠', main: '🏠', sockets: '🤖', socket: '🤖',
  stickers: '🖼️', downloads: '📥', utils: '🛠️', utilidades: '🛠️',
  profile: '👤', group: '👥', economy: '💰', gacha: '🎴',
  nsfw: '🔞', moderacao: '🛡️', noticias: '📰',
  owner: '👑', security: '🔐', pagamentos: '💳',
  ia_cmds: '🤖', games: '🎮', fun: '🎉', anime: '🍙'
};

const HIDDEN_CATS = new Set(['_disabled', 'owner']);

export default {
  command: ['menu', 'allmenu', 'ajuda', 'comandos', 'help'],
  category: 'main',
  description: 'Menu unificado de elite do NEXUS OMEGA v20.',
  run: async ({ msg, sock, args, usedPrefix, pushname, isOwner }) => {
    try {
      const botId = sock.user.id.split(':')[0] + '@s.whatsapp.net';
      const settings = db.getSettings(botId) || {};
      const totalUsers = (db.getUser() || []).length || 0;
      const totalGroups = (db.getChat() || []).length || 0;
      const uptime = formatUptime(Date.now() - (global.bootTime || Date.now()));
      const hora = moment().tz('Africa/Maputo').format('HH:mm');
      const data = moment().tz('Africa/Maputo').format('DD/MM/YYYY');
      const prefix = usedPrefix || '.';
      const channelLink = settings?.link || 'https://whatsapp.com/channel/0029Vb8SJi3BFLgQL1wCTr3N';

      const randomImg = getRandomOmegaImage();

      const input = (args[0] || '').toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '');

      const categoryAliases = {
        ia:          ['ia', 'ai', 'inteligencia', 'brain', 'omega'],
        downloads:   ['downloads', 'download', 'baixar', 'dl'],
        stickers:    ['stickers', 'figurinhas', 'stick'],
        utils:       ['utils', 'utilidades', 'ferramentas', 'tools'],
        utilidades:  ['utilidade'],
        group:       ['grupos', 'grupo', 'gp', 'group'],
        profile:     ['perfil', 'profile', 'me', 'eu'],
        economy:     ['economy', 'economia', 'eco', 'money', 'dinheiro'],
        gacha:       ['gacha', 'waifu', 'jogos'],
        nsfw:        ['nsfw', '18', 'adulto'],
        moderacao:   ['moderacao', 'mod', 'seguranca'],
        noticias:    ['noticias', 'news', 'jornal'],
        pagamentos:  ['pagamentos', 'mpesa', 'pagar'],
        sockets:     ['sockets', 'bot', 'sessao'],
        main:        ['main', 'principal', 'geral'],
        anime:       ['anime', 'otaku'],
        security:    ['security', 'seguridade']
      };

      const matchedCat = Object.keys(categoryAliases).find(k =>
        categoryAliases[k].some(a => a === input || input.startsWith(a))
      );

      if (input && !matchedCat) {
        return msg.reply(`❌ *Categoria "${args[0]}" não encontrada.*\n\n> Use *${prefix}menu* para ver todas as categorias disponíveis.`);
      }

      const categories = {};
      for (const [name, cmd] of global.comandos) {
        if (!name || name.startsWith('_')) continue;
        const cat = (cmd.category || 'utils').toLowerCase();
        if (HIDDEN_CATS.has(cat)) continue;
        if (!categories[cat]) categories[cat] = new Set();
        categories[cat].add(name);
      }

      if (matchedCat) {
        const catsToShow = Object.keys(categories).filter(c =>
          c === matchedCat || (categoryAliases[matchedCat] || []).some(a => c.startsWith(a))
        );

        if (!catsToShow.length) {
          return msg.reply(`❌ Nenhum comando encontrado para "${args[0]}". Use *${prefix}menu* para ver categorias.`);
        }

        const icon = CATEGORY_ICONS[matchedCat] || '📁';
        const allCmds = new Set();
        for (const c of catsToShow) {
          for (const cmd of categories[c]) allCmds.add(cmd);
        }
        const cmds = [...allCmds].sort();

        const catMenu = `
╭━━━━━━━━━━━━━━━━━━━━━━━━━━━━━╮
┃  ${icon} *${matchedCat.toUpperCase()}* · NEXUS OMEGA
╰━━━━━━━━━━━━━━━━━━━━━━━━━━━━━╯

${cmds.map(c => `  ◈ *${prefix}${c}*`).join('\n')}

╭─────────────────────────────╮
│ Total: *${cmds.length} comandos*
│ Use *${prefix}menu* para voltar
╰─────────────────────────────╯`;

        await msg.react('📋');
        return sock.sendMessage(msg.chat, {
          image: { url: randomImg },
          caption: catMenu.trim(),
          contextInfo: { mentionedJid: [msg.sender] }
        }, { quoted: msg });
      }

      const ownerBadge = isOwner ? '\n┃  👑 *MODO ARQUITETO ATIVO*' : '';

      const ORDER = ['main', 'ia', 'downloads', 'stickers', 'utils', 'utilidades', 'group', 'profile', 'economy', 'gacha', 'moderacao', 'pagamentos', 'noticias', 'nsfw', 'anime', 'sockets', 'security'];
      const sortedCats = Object.keys(categories).sort((a, b) => {
        const ia = ORDER.indexOf(a);
        const ib = ORDER.indexOf(b);
        if (ia === -1 && ib === -1) return a.localeCompare(b);
        if (ia === -1) return 1;
        if (ib === -1) return -1;
        return ia - ib;
      });

      let catList = '';
      for (const cat of sortedCats) {
        const icon = CATEGORY_ICONS[cat] || '📁';
        const count = categories[cat].size;
        catList += `┃  ${icon} *${cat.charAt(0).toUpperCase() + cat.slice(1)}* — ${count} cmds → *${prefix}menu ${cat}*\n`;
      }

      const totalCmds = global.comandos ? global.comandos.size : 0;

      const menuText = `
╭━━━━━━━━━━━━━━━━━━━━━━━━━━━━━╮
┃  🌌 **NEXUS OMEGA v20**
┃  _A Singularidade de Nel Custódio_ 🇲🇿${ownerBadge}
╰━━━━━━━━━━━━━━━━━━━━━━━━━━━━━╯

╭─ 📊 **ESTATÍSTICAS OMEGA** ─╮
┃  👤 Arquiteto: *${pushname}*
┃  ⏱️ Uptime: *${uptime}*
┃  👥 Cidadãos: *${totalUsers}* | 🏰 Grupos: *${totalGroups}*
┃  🕒 Hora: *${hora}* | 📅 *${data}*
┃  ⚡ Potencial: *${totalCmds} Comandos Omega*
╰──────────────────────────────╯

╭─ 📋 **NÚCLEOS DE COMANDO — menu <categoria>** ─╮
${catList}╰──────────────────────────────╯

╭─ 💡 *EXEMPLOS* ──────────────╮
┃  • *${prefix}menu ia* — Comandos de IA
┃  • *${prefix}menu downloads* — Downloads
┃  • *${prefix}menu utils* — Ferramentas
┃  • *${prefix}menu grupos* — Gestão de grupos
┃  • *${prefix}menu stickers* — Figurinhas
┃  • *${prefix}ping* — Testar latência
╰──────────────────────────────╯

╭─ 🔗 *LINKS OFICIAIS* ────────╮
┃  📢 Canal: ${channelLink}
┃  👑 Arquiteto: **Nel Custódio** (Boane/Zambézia)
┃  🎓 Escola: *Joaquim Chissano*
╰──────────────────────────────╯

> 🧠 _"A inteligência que transcende limites."_
> ⚡ **NEXUS OMEGA v20 — O Império Tecnológico de Moçambique**`;

      await msg.react('🌌');
      return sock.sendMessage(msg.chat, {
        image: { url: randomImg },
        caption: menuText.trim(),
        contextInfo: {
          mentionedJid: [msg.sender],
          externalAdReply: {
            title: '🌌 NEXUS OMEGA v20',
            body: 'O Bot Mais Avançado de Moçambique 🇲🇿',
            thumbnailUrl: 'https://files.manuscdn.com/user_upload_by_module/session_file/310519663816274487/ISALFhwAnOmlwENj.png',
            sourceUrl: channelLink,
            mediaType: 1,
            renderLargerThumbnail: true
          }
        }
      }, { quoted: msg });

    } catch (e) {
      console.error('[ MENU ERROR ]', e);
      await msg.reply(`❌ Erro ao carregar o menu: ${e.message}`);
    }
  }
};
