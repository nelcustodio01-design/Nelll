/**
 * 🔍 SPY-WEB — Extrair e resumir informações de qualquer link
 * Corrigido: removido VIP Elite, fix API
 */
import fetch from 'node-fetch';

export default {
  command: ['spy-web', 'link-info', 'resumir-link', 'webinfo'],
  category: 'ia',
  description: 'Extrair e resumir informações de qualquer link 🔍',
  run: async ({ msg, sock, text, args, usedPrefix, command }) => {
    const url = text || args[0];
    if (!url) return msg.reply(
      `🔍 *SPY-WEB: ANÁLISE DE LINKS*\n\n` +
      `Envia um link para eu analisar e resumir!\n\n` +
      `Exemplo: *${usedPrefix}${command} https://exemplo.com/noticia*`
    );

    await msg.react('🔍');
    const { key } = await sock.sendMessage(msg.chat, { text: `🔍 A analisar o link...\n🔗 _${url}_` }, { quoted: msg });

    try {
      let extractedContent = null;

      // Extrair conteúdo da página
      try {
        const res = await fetch(`https://api.vreden.web.id/api/tools/web-extract?url=${encodeURIComponent(url)}`, { timeout: 15000 });
        const data = await res.json();
        if (data?.status && data?.result) extractedContent = data.result;
      } catch {}

      if (!extractedContent) {
        try {
          const res = await fetch(`https://api.delirius.store/tools/webinfo?url=${encodeURIComponent(url)}`, { timeout: 15000 });
          const data = await res.json();
          if (data?.status && data?.data) extractedContent = typeof data.data === 'string' ? data.data : JSON.stringify(data.data);
        } catch {}
      }

      if (!extractedContent) {
        return sock.sendMessage(msg.chat, {
          text: `❌ Não consegui aceder ao conteúdo de:\n🔗 ${url}\n\nVerifica se a URL está acessível.`, edit: key
        }, { quoted: msg });
      }

      // Resumir com IA
      const resumoPrompt = `Resume de forma clara e objectiva em português o seguinte conteúdo:\n\n${extractedContent.substring(0, 2000)}`;
      let resumo = null;

      try {
        const res = await fetch(`https://api.vreden.web.id/api/ai/chatgpt?text=${encodeURIComponent(resumoPrompt)}`, { timeout: 20000 });
        const data = await res.json();
        if (data?.status && data?.result) resumo = data.result;
      } catch {}

      if (!resumo) {
        resumo = extractedContent.substring(0, 800) + (extractedContent.length > 800 ? '...' : '');
      }

      await sock.sendMessage(msg.chat, {
        text: `🔍 *ANÁLISE SPY-WEB*\n\n🔗 ${url}\n\n${resumo}\n\n> ⚡ _Nexus Singularity V14_`, edit: key
      }, { quoted: msg });
      await msg.react('✅');
    } catch (e) {
      await sock.sendMessage(msg.chat, { text: `❌ Não consegui analisar esse link: ${e.message}`, edit: key }, { quoted: msg });
    }
  }
};
