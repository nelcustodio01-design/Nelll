import db from '#db';
export default {
  command: ['report', 'relatório', 'sug', 'suggest'],
  category: 'main',
  description: 'Enviar uma sugestão aos moderadores.',
  run: async ({ msg, sock, command, text }) => {
    const texto = text.trim();
    const now = Date.now();
    const esReporte = ['report', 'relatório'].includes(command);
    const cooldownHours = 12;
    const cooldownMs = cooldownHours * 60 * 60 * 1000;
    const userKey = esReporte ? 'reportCooldown' : 'sugCooldown';
    db.setCreate('users', msg.sender, userKey, 0);
    let user = db.getUser(msg.sender);
    const cooldown = user[userKey] || 0;
    const restante = cooldown - now;
    if (restante > 0) {
      return msg.reply(`ꕥ Espere *${msToTime(restante)}* para voltar a ${esReporte ? 'relatar' : 'sugerir'}.`);
    }
    if (!texto) {
      return msg.reply(`《✧》 Deve *escrever* o ${esReporte ? '*relatório*' : '*sugestão*'}.`);
    }
    if (texto.length < 10) {
      return msg.reply(`《✧》 A sua mensagem é *muito curta*. Explique melhor o seu ${esReporte ? 'relatório' : 'sugestão'} (mínimo 10 caracteres)`);
    }
    const fecha = new Date();
    const fechaLocal = fecha.toLocaleDateString('es-MX', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' });
    const tipo = esReporte ? '🆁ҽ𝕡σɾƚҽ' : '🆂մց𝕖ɾҽ𝚗cíᥲ';
    const tipo2 = esReporte ? 'ꕥ Reporte' : 'ꕥ Sugerencia';
    const name = user?.name || msg.pushName || 'Usuário desconhecido';
    const numero = msg.sender.split('@')[0];
    const pp = await sock.profilePictureUrl(msg.sender, 'image').catch(() => 'https://cdn.yuki-wabot.my.id/files/2PVh.jpeg');
    const botId = sock.user.id.split(':')[0] + '@s.whatsapp.net';
    const botSettings = db.getSettings(botId) || {};
    const isOficialBot = botId === ((global.sock?.user?.id?.split(':')[0] ?? null) && ((global.sock?.user?.id?.split(':')[0] ?? null) && (global.sock.user.id.split(':')[0] + '@s.whatsapp.net')));
    const botType = isOficialBot ? 'Principal/Dono' : 'Sub Bot';
    let reportMsg = `🫗۫᷒ᰰ⃘ׅ᷒  ۟　\`${tipo}\`　ׅ　ᩡ\n\n𖹭  ׄ  ְ ❖ *Nome*\n> ${name}\n\n𖹭  ׄ  ְ ❖ *Número*\n> wa.me/${numero}\n\n𖹭  ׄ  ְ ❖ *Data*\n> ${fechaLocal}\n\n𖹭  ׄ  ְ ❖ *Socket*\n> ${botType}\n\n𖹭  ׄ  ְ ❖ *Mensagem*\n> ${texto}\n\n`;
    for (const num of global.owner) {
      try {
        await sock.sendMessage(`${num}@s.whatsapp.net`, { text: reportMsg });
      } catch {}
    }    
    db.setUser(msg.sender, userKey, now + cooldownMs);
    msg.reply(`《✧》 Obrigado pelo seu *${esReporte ? 'relatório' : 'sugestão'}*\n\n> A sua mensagem foi enviada correctamente aos moderadores`);
  },
};

const msToTime = (duration) => {
  const seconds = Math.floor((duration / 1000) % 60);
  const minutes = Math.floor((duration / (1000 * 60)) % 60);
  const hours = Math.floor((duration / (1000 * 60 * 60)) % 24);
  const days = Math.floor(duration / (1000 * 60 * 60 * 24));
  const s = seconds.toString().padStart(2, '0');
  const m = minutes.toString().padStart(2, '0');
  const h = hours.toString().padStart(2, '0');
  const d = days.toString();
  const parts = [];
  if (days > 0) parts.push(`${d} dia${d > 1 ? 's' : ''}`);
  if (hours > 0) parts.push(`${h} hora${h > 1 ? 's' : ''}`);
  if (minutes > 0) parts.push(`${m} minuto${m > 1 ? 's' : ''}`);
  parts.push(`${s} segundo${s > 1 ? 's' : ''}`);
  return parts.join(', ');
};