export default {
  command: ['criador', 'owner', 'dono', 'dev'],
  category: 'main',
  description: 'Informações sobre o criador do bot.',
  run: async ({ msg, sock, usedPrefix, command }) => {
    const ownerNumber = String(global.ownerNumbers?.[0] || '').replace(/\D/g, '');
    const contact = ownerNumber ? `wa.me/${ownerNumber}` : 'não configurado';
    return msg.reply(
      `❧ *Informações do Criador* 👑\n\n` +
      `▸ Nome: *Nel Custódio*\n` +
      `▸ Número: *${ownerNumber || 'não configurado'}*\n` +
      `▸ País: *Moçambique* 🇲🇿\n` +
      `▸ Projecto: *Nel-Aviso-Bot-Moz*\n` +
      `▸ Versão: *4.0*\n\n` +
      `▸ Contacto: ${contact}\n\n` +
      `🔥 Feito com amor por Nel 🇲🇿\n` +
      `▸ Este bot é único e feito em Moçambique!`
    );
  },
};
